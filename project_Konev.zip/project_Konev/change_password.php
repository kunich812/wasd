<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
require_once 'db.php';

// Только для авторизованных
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

$error   = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current = trim($_POST['current_password'] ?? '');
    $new     = trim($_POST['new_password'] ?? '');
    $confirm = trim($_POST['confirm_password'] ?? '');

    // 1. Все поля заполнены
    if ($current === '' || $new === '' || $confirm === '') {
        $error = 'Заполните все поля.';
    }
    // 2. Длина нового пароля 6–12
    elseif (mb_strlen($new) < 6 || mb_strlen($new) > 12) {
        $error = 'Новый пароль должен содержать от 6 до 12 символов.';
    }
    // 3. Новый и подтверждение совпадают
    elseif ($new !== $confirm) {
        $error = 'Новый пароль и подтверждение не совпадают.';
    }
    // 4. Новый отличается от текущего
    elseif ($new === $current) {
        $error = 'Новый пароль должен отличаться от текущего.';
    }
    else {
        // 5. Получаем текущий хэш
        $stmt = $conn->prepare("SELECT `password` FROM `user` WHERE `id_u` = ?");
        $stmt->bind_param("i", $_SESSION['user_id']);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$row) {
            $error = 'Пользователь не найден.';
        }
        // 6. Проверяем текущий пароль
        elseif (!password_verify($current, $row['password'])) {
            $error = 'Текущий пароль указан неверно.';
        }
        else {
            // 7. Хэшируем новый и обновляем
            $newHash = password_hash($new, PASSWORD_BCRYPT);
            $stmt = $conn->prepare("UPDATE `user` SET `password` = ? WHERE `id_u` = ?");
            $stmt->bind_param("si", $newHash, $_SESSION['user_id']);

            if ($stmt->execute()) {
                $success = 'Пароль успешно изменён.';

                // Сбрасываем предупреждение об устаревшем пароле
                unset($_SESSION['password_expired_warning']);
            } else {
                $error = 'Не удалось обновить пароль: ' . $conn->error;
            }
            $stmt->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Смена пароля</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body { font-family: sans-serif; background: #f4f6f9; padding: 30px; }
        .container { max-width: 480px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
        h1 { font-size: 22px; margin-bottom: 20px; color: #333; }
        .alert { padding: 12px 16px; border-radius: 6px; font-size: 14px; margin-bottom: 20px; }
        .alert-error   { background: rgba(239,68,68,0.1);  border: 1px solid rgba(239,68,68,0.3);  color: #ef4444; }
        .alert-success { background: rgba(34,197,94,0.1);  border: 1px solid rgba(34,197,94,0.3);  color: #16a34a; }
        .form-group { margin-bottom: 16px; }
        .form-group label { display: block; margin-bottom: 6px; font-weight: 500; font-size: 13px; color: #666; }
        .form-group input { width: 100%; padding: 10px 12px; border: 1.5px solid #ddd; border-radius: 6px; font-size: 14px; box-sizing: border-box; }
        .form-group input:focus { outline: none; border-color: #6366f1; }
        .btn { display: inline-block; padding: 11px 18px; border: none; border-radius: 6px; font-size: 14px; font-weight: 600; cursor: pointer; text-decoration: none; }
        .btn-primary { background: linear-gradient(135deg, #6366f1, #4f46e5); color: white; }
        .btn-primary:hover { box-shadow: 0 6px 14px rgba(99,102,241,0.35); }
        .btn-secondary { background: #e5e7eb; color: #333; margin-left: 8px; }
        .hint { color: #888; font-size: 12px; margin-top: 4px; }
    </style>
</head>
<body>
    <div class="container">
        <h1><i class="fas fa-key"></i> Смена пароля</h1>

        <?php if ($error): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?>
            </div>
        <?php endif; ?>

     <<form method="post">
     <div class="form-group">
        <label for="current_password">Текущий пароль</label>
        <input type="password" id="current_password" name="current_password"
               required
               title="Введите пароль, под которым вы сейчас вошли"
               oninvalid="this.setCustomValidity('Заполните это поле')"
               oninput="this.setCustomValidity('')">
     </div>

     <div class="form-group">
        <label for="new_password">Новый пароль</label>
        <input type="password" id="new_password" name="new_password"
               minlength="6" maxlength="12" required
               title="От 6 до 12 символов"
               oninvalid="this.setCustomValidity(
                   this.validity.valueMissing
                       ? 'Заполните это поле'
                       : 'Новый пароль должен содержать от 6 до 12 символов'
               )"
               oninput="this.setCustomValidity('')">
        <div class="hint">От 6 до 12 символов</div>
     </div>

     <div class="form-group">
        <label for="confirm_password">Повторите новый пароль</label>
        <input type="password" id="confirm_password" name="confirm_password"
               minlength="6" maxlength="12" required
               title="Повторите новый пароль один в один"
               oninvalid="this.setCustomValidity(
                   this.validity.valueMissing
                       ? 'Заполните это поле'
                       : 'Пароль должен содержать от 6 до 12 символов'
               )"
               oninput="this.setCustomValidity('')">
     </div>

     <button type="submit" class="btn btn-primary">
        <i class="fas fa-save"></i> Сохранить
     </button>
     <a href="dashboard.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Назад
     </form>
    </div>
</body>
</html>