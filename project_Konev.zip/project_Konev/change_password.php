<?php

declare(strict_types=1);

error_reporting(E_ALL);
ini_set('display_errors', '1');

session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

$error   = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current = trim($_POST['current_password'] ?? '');
    $new     = trim($_POST['new_password'] ?? '');
    $confirm = trim($_POST['confirm_password'] ?? '');

    if ($current === '' || $new === '' || $confirm === '') {
        $error = 'Заполните все поля.';
    } elseif (mb_strlen($new) < 6 || mb_strlen($new) > 12) {
        $error = 'Новый пароль должен содержать от 6 до 12 символов.';
    } elseif ($new !== $confirm) {
        $error = 'Новый пароль и подтверждение не совпадают.';
    } elseif ($new === $current) {
        $error = 'Новый пароль должен отличаться от текущего.';
    } else {
        $stmt = $conn->prepare("SELECT `password` FROM `user` WHERE `id_u` = ?");
        $stmt->bind_param('i', $_SESSION['user_id']);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$row) {
            $error = 'Пользователь не найден.';
        } elseif (!password_verify($current, $row['password'])) {
            $error = 'Текущий пароль указан неверно.';
        } else {
            $newHash = password_hash($new, PASSWORD_BCRYPT);
            $stmt = $conn->prepare("UPDATE `user` SET `password` = ? WHERE `id_u` = ?");
            $stmt->bind_param('si', $newHash, $_SESSION['user_id']);

            if ($stmt->execute()) {
                $success = 'Пароль успешно изменён.';
                unset($_SESSION['password_expired_warning']);
            } else {
                $error = 'Не удалось обновить пароль: ' . $conn->error;
            }
            $stmt->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Смена пароля</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container change-pass-container">
        <h1><i class="fas fa-key"></i> Смена пароля</h1>

        <?php if ($error) : ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <?php if ($success) : ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?>
            </div>
        <?php endif; ?>

        <form method="post">
            <div class="form-group">
                <label for="current_password">Текущий пароль</label>
                <input type="password" id="current_password" name="current_password"
                       required
                       title="Введите пароль, под которым вы сейчас вошли"
                       oninvalid="this.setCustomValidity('Заполните это поле')"
                       oninput="this.setCustomValidity('')">
            </div>

            <div class="form-group">
                <label for="new_password">Новый пароль</label>
                <input type="password" id="new_password" name="new_password"
                       minlength="6" maxlength="12" required
                       title="От 6 до 12 символов"
                       oninvalid="this.setCustomValidity(
                           this.validity.valueMissing
                               ? 'Заполните это поле'
                               : 'Новый пароль должен содержать от 6 до 12 символов'
                       )"
                       oninput="this.setCustomValidity('')">
                <div class="hint">От 6 до 12 символов</div>
            </div>

            <div class="form-group">
                <label for="confirm_password">Повторите новый пароль</label>
                <input type="password" id="confirm_password" name="confirm_password"
                       minlength="6" maxlength="12" required
                       title="Повторите новый пароль один в один"
                       oninvalid="this.setCustomValidity(
                           this.validity.valueMissing
                               ? 'Заполните это поле'
                               : 'Пароль должен содержать от 6 до 12 символов'
                       )"
                       oninput="this.setCustomValidity('')">
            </div>

            <div class="btn-block-mt">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> Сохранить
                </button>
                <a href="dashboard.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Назад
                </a>
            </div>
        </form>
    </div>
</body>
</html>