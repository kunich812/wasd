<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}
$isSysadmin = ($_SESSION['role'] ?? '') === 'sysadmin';
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Главная панель</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <?php if (isset($_SESSION['password_expired_warning'])): ?>
            <div class="alert-warning">
                <strong><i class="fas fa-exclamation-triangle"></i> Внимание!</strong> Ваш пароль не обновлялся более 6 месяцев. Рекомендуем сменить его.
            </div>
            <?php unset($_SESSION['password_expired_warning']); ?>
        <?php endif; ?>

        <h1>Добро пожаловать, <?= htmlspecialchars($_SESSION['first_name'] . ' ' . $_SESSION['last_name']) ?>!</h1>
        
        <p><strong>Логин:</strong> <?= htmlspecialchars($_SESSION['login']) ?></p>
        <p><strong>Роль:</strong> <span class="role-badge"><?= htmlspecialchars($_SESSION['role']) ?></span></p>
        <p><strong>Email:</strong> <?= htmlspecialchars($_SESSION['email']) ?></p>

        <?php if ($isSysadmin): ?>
            <div class="admin-panel">
                <h3><i class="fas fa-shield-alt"></i> Зона администратора</h3>
                <a href="admin/index.php" class="btn btn-secondary">
                    <i class="fas fa-users-cog"></i> Перейти в Админ-панель
                </a>
            </div>
        <?php endif; ?>

        <div class="actions">
            <a href="notes.php" class="btn btn-primary">
                <i class="fas fa-sticky-note"></i> Мои заметки
            </a>
            <a href="change_password.php" class="btn btn-secondary">
                <i class="fas fa-key"></i> Сменить пароль
            </a>
            <a href="logout.php" class="btn btn-danger" style="margin-left: auto;"
               onclick="return confirm('Вы уверены, что хотите выйти из системы?')">
                <i class="fas fa-sign-out-alt"></i> Выйти
            </a>
        </div>
    </div>
</body>
</html>