<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Главная панель</title>
    <style>
        body { font-family: sans-serif; background: #f4f6f9; padding: 30px; }
        .container { max-width: 800px; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
        .alert-warning { background: #fff3cd; border: 1px solid #ffeeba; color: #856404; padding: 15px; border-radius: 6px; margin-bottom: 20px; }
        .btn-logout { display: inline-block; padding: 10px 15px; background: #ef4444; color: white; text-decoration: none; border-radius: 5px; }
    </style>
</head>
<body>
    <div class="container">
        <!-- Блок сообщения об устаревшем пароле -->
        <?php if (isset($_SESSION['password_expired_warning'])): ?>
            <div class="alert-warning">
                <strong>Внимание!</strong> Ваш пароль не обновлялся более 6 месяцев. 
                В целях безопасности настоятельно рекомендуем сменить его.
            </div>
            <?php unset($_SESSION['password_expired_warning']); ?>
        <?php endif; ?>

        <h1>Добро пожаловать, <?= htmlspecialchars($_SESSION['first_name'] . ' ' . $_SESSION['last_name']) ?>!</h1>
        <p><strong>Ваш логин:</strong> <?= htmlspecialchars($_SESSION['login']) ?></p>
        <p><strong>Ваша роль в системе:</strong> <?= htmlspecialchars($_SESSION['role']) ?></p>
        <p><strong>Email:</strong> <?= htmlspecialchars($_SESSION['email']) ?></p>
        
        <br><br>
       <a href="change_password.php" style="display:inline-block; padding:10px 15px; background:#6366f1; color:white; text-decoration:none; border-radius:5px; margin-right:8px;">
       Сменить пароль
       </a>
       <a href="logout.php" class="btn-logout">Выйти из системы</a>
    </div>
</body>
</html>