<?php
if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit('Доступ только из командной строки');
}

require_once 'db.php';

$users = [
    'sysadmin_1' => 'Sysadm1n1',
    'sysadmin_2' => 'Sysadm1n2', // заблокирован
    'admin_01'   => 'Adm1n_001',
    'admin_02'   => 'Adm1n_002', // заблокирован
    'user_001'   => 'User_0001',
    'user_002'   => 'User_0002', // заблокирован
    'user_003'   => 'User_0003', 
];

$stmt = $conn->prepare("SELECT password FROM `user` WHERE login = ?");

foreach ($users as $login => $pwd) {
    $stmt->bind_param("s", $login);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();

    if (!$row) {
        echo str_pad($login, 12) . " NOT FOUND" . PHP_EOL;
        continue;
    }

    $ok = password_verify($pwd, $row['password']) ? 'OK' : 'FAIL';
    echo str_pad($login, 12) . " $ok" . PHP_EOL;
}