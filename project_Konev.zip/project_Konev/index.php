<?php

declare(strict_types=1);

error_reporting(E_ALL);
ini_set('display_errors', '1');
session_start();
require_once 'db.php';

if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

// Включаем тестовый режим для Selenium
if (isset($_GET['test_mode']) && $_GET['test_mode'] === '1') {
    $_SESSION['test_mode_active'] = true;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login        = trim($_POST['login'] ?? '');
    $password     = trim($_POST['password'] ?? '');
    $puzzleUser   = $_POST['puzzle_order'] ?? '';
    $puzzleCorrect = $_SESSION['puzzle_answer'] ?? '';
    $modalCaptchaVerified = $_SESSION['captcha_verified'] ?? false;

    // Если тестовый режим активен — пропускаем капчу
    if (!empty($_SESSION['test_mode_active'])) {
        $puzzleUser = $puzzleCorrect;
        $modalCaptchaVerified = true;
    }

    unset($_SESSION['puzzle_answer'], $_SESSION['puzzle_id'], $_SESSION['captcha_verified'], $_SESSION['captcha_code']);

    if ($puzzleUser !== $puzzleCorrect) {
        $error = 'Пазл собран неверно. Попробуйте ещё раз.';
    } elseif (!$modalCaptchaVerified) {
        $error = 'Вторая капча не пройдена. Попробуйте ещё раз.';
    } elseif ($login && $password) {
        $stmt = $conn->prepare("
            SELECT *, 
            (password_created_at <= NOW() - INTERVAL 6 MONTH) AS password_expired 
            FROM `user` 
            WHERE `login` = ?
        ");
        $stmt->bind_param('s', $login);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($user = $result->fetch_assoc()) {
            if ($user['is_blocked'] === 'да') {
                $error = 'Ваш аккаунт заблокирован администратором.';
            } elseif (password_verify($password, $user['password'])) {
                $_SESSION['user_id']    = $user['id_u'];
                $_SESSION['login']      = $user['login'];
                $_SESSION['role']       = $user['role'];
                $_SESSION['first_name'] = $user['first_name'];
                $_SESSION['last_name']  = $user['last_name'];
                $_SESSION['email']      = $user['email'];
                
                if ($user['password_expired'] == 1) {
                    $_SESSION['password_expired_warning'] = true;
                }
                
                // Отключаем тестовый режим после успешного входа
                unset($_SESSION['test_mode_active']);
                
                header('Location: dashboard.php');
                exit;
            } else {
                $error = 'Неверный логин или пароль.';
            }
        } else {
            $error = 'Неверный логин или пароль.';
        }
        $stmt->close();
    } else {
        $error = 'Заполните все поля.';
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Авторизация</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body class="login-page">
    <div class="login-container">
        <div class="login-card">
            <div class="login-header">
                <h1>Вход в систему</h1>
                <p>Панель управления пользователями</p>
            </div>

            <?php if ($error) : ?>
                <div class="alert-error">
                    <i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>

            <form method="post" id="loginForm">
                <div class="form-group">
                    <label for="login"><i class="fas fa-user"></i> Логин</label>
                    <input type="text" id="login" name="login" placeholder="Введите логин"
                           value="<?= htmlspecialchars($_POST['login'] ?? '') ?>" required autofocus>
                </div>

                <div class="form-group">
                    <label for="password"><i class="fas fa-lock"></i> Пароль</label>
                    <input type="password" id="password" name="password" placeholder="Введите пароль" required>
                </div>

                <div class="form-group">
                    <label><i class="fas fa-puzzle-piece"></i> Соберите картинку</label>
                    <div id="puzzle-board" class="puzzle-board">
                        <div style="grid-column: span 2; text-align: center; color: #999; padding-top: 80px;">
                            <i class="fas fa-spinner fa-spin"></i> Загрузка...
                        </div>
                    </div>
                    <input type="hidden" id="puzzle_order" name="puzzle_order" required>
                    <div class="puzzle-hint">Перетащите кусочки мышкой, чтобы собрать изображение</div>
                </div>

                <button type="submit" class="btn-login">
                    <i class="fas fa-sign-in-alt"></i> Войти в систему
                </button>
            </form>
        </div>
    </div>

    <!-- Модальное окно 2-й капчи -->
    <div id="captchaModal" class="modal-overlay" style="display: none;">
        <div class="modal-content">
            <h3><i class="fas fa-shield-alt"></i> Подтверждение</h3>
            <p>Введите код с картинки, чтобы войти</p>
            
            <img src="captcha.php" id="modalCaptchaImg" alt="Капча" class="modal-captcha-img"
                 onclick="this.src='captcha.php?' + Math.random()" title="Нажмите, чтобы обновить">

            <input type="text" id="modal_captcha_input" maxlength="5" placeholder="Введите код" 
                   autocomplete="off" class="modal-captcha-input">

            <input type="hidden" name="modal_captcha" id="modal_captcha_hidden">

            <div class="modal-actions">
                <button type="button" class="btn btn-secondary" onclick="closeModal()">Отмена</button>
                <button type="button" class="btn btn-primary" id="modalSubmitBtn" onclick="submitWithCaptcha()">Войти</button>
            </div>
        </div>
    </div>

    <script>
        let draggedPiece = null;
        let initialPuzzleOrder = '';

        async function loadPuzzle() {
            const board = document.getElementById('puzzle-board');
            board.innerHTML = `<div style="grid-column: span 2; text-align: center; color: #999; padding-top: 80px;"><i class="fas fa-spinner fa-spin"></i> Загрузка...</div>`;
            try {
                const res = await fetch('api/captcha_puzzle.php');
                const data = await res.json();
                if (data.error) {
                    board.innerHTML = `<div style="grid-column:span 2; color:red; text-align:center; padding-top:80px;">${data.error}</div>`;
                    return;
                }
                board.innerHTML = '';
                data.pieces.forEach(pieceFile => {
                    const div = document.createElement('div');
                    div.className = 'puzzle-piece';
                    div.draggable = true;
                    div.style.backgroundImage = `url('captcha_tmp/${pieceFile}')`;
                    div.dataset.piece = pieceFile.split('_')[1].replace('.png', ''); 
                    div.addEventListener('dragstart', handleDragStart);
                    div.addEventListener('dragover', handleDragOver);
                    div.addEventListener('drop', handleDrop);
                    div.addEventListener('dragend', handleDragEnd);
                    board.appendChild(div);
                });
                updateOrder();
                initialPuzzleOrder = document.getElementById('puzzle_order').value;
            } catch (e) { console.error(e); }
        }

        function handleDragStart(e) { draggedPiece = this; this.classList.add('dragging'); e.dataTransfer.effectAllowed = 'move'; }
        function handleDragOver(e) { e.preventDefault(); e.dataTransfer.dropEffect = 'move'; return false; }
        function handleDrop(e) {
            e.stopPropagation();
            if (draggedPiece !== this) {
                let draggedNext = draggedPiece.nextSibling;
                let targetNext = this.nextSibling;
                let parent = this.parentNode;
                parent.insertBefore(draggedPiece, targetNext);
                parent.insertBefore(this, draggedNext);
                updateOrder();
            }
            return false;
        }
        function handleDragEnd() { this.classList.remove('dragging'); draggedPiece = null; }
        
        function updateOrder() {
            const pieces = document.querySelectorAll('.puzzle-piece');
            const order = Array.from(pieces).map(p => p.dataset.piece).join(',');
            document.getElementById('puzzle_order').value = order;
        }

        const loginForm = document.getElementById('loginForm');
        const modal = document.getElementById('captchaModal');
        
        loginForm.addEventListener('submit', function(e) {
            // Если мы в тестовом режиме (Selenium) - пропускаем всё
            const isTestMode = window.location.search.includes('test_mode=1');
            if (isTestMode) return;

            const currentOrder = document.getElementById('puzzle_order').value;
            
            if (!currentOrder || currentOrder === initialPuzzleOrder) {
                e.preventDefault(); 
                alert('Пожалуйста, соберите пазл (перетащите кусочки).'); 
                return;
            }
            
            if (loginForm.dataset.submitted === 'true') return; 
            
            e.preventDefault();
            modal.style.display = 'flex';
            document.getElementById('modalCaptchaImg').src = 'captcha.php?' + Math.random();
            document.getElementById('modal_captcha_input').value = '';
            document.getElementById('modal_captcha_input').focus();
        });
        
        function closeModal() { modal.style.display = 'none'; document.getElementById('modal_captcha_input').value = ''; }
        
        function submitWithCaptcha() {
            const code = document.getElementById('modal_captcha_input').value.trim();
            if (code.length < 4) { alert('Введите код полностью.'); return; }
            const btn = document.getElementById('modalSubmitBtn');
            btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Проверка...';
            
            fetch('api/verify_captcha.php', {
                method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'code=' + encodeURIComponent(code)
            }).then(res => res.json()).then(data => {
                if (data.success) {
                    document.getElementById('modal_captcha_hidden').value = code;
                    loginForm.dataset.submitted = 'true'; 
                    loginForm.submit();
                } else {
                    alert('Неверный код! Попробуйте еще раз.');
                    document.getElementById('modalCaptchaImg').src = 'captcha.php?' + Math.random();
                    document.getElementById('modal_captcha_input').value = '';
                    btn.disabled = false; btn.innerHTML = 'Войти';
                }
            });
        }
        
        loadPuzzle();
        loginForm.dataset.submitted = 'false';
    </script>
</body>
</html>