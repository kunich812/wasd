<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
require_once 'db.php';

if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login        = trim($_POST['login'] ?? '');
    $password     = trim($_POST['password'] ?? '');
    $captchaInput = strtoupper(trim($_POST['captcha'] ?? ''));
    $captchaReal  = $_SESSION['captcha_code'] ?? '';

    // Капча одноразовая — сбрасываем сразу
    unset($_SESSION['captcha_code']);

    // 1. Проверка капчи
    if ($captchaInput === '' || $captchaInput !== $captchaReal) {
        $error = 'Неверный код с картинки. Попробуйте ещё раз.';
    }
    // 2. Проверка логина и пароля
    elseif ($login && $password) {
        $stmt = $conn->prepare("
            SELECT *, 
            (password_created_at <= NOW() - INTERVAL 6 MONTH) AS password_expired 
            FROM `user` 
            WHERE `login` = ?
        ");
        $stmt->bind_param("s", $login);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($user = $result->fetch_assoc()) {
            if ($user['is_blocked'] === 'да') {
                $error = 'Ваш аккаунт заблокирован администратором.';
            } elseif (password_verify($password, $user['password'])) {
                $_SESSION['user_id']    = $user['id_u'];
                $_SESSION['login']      = $user['login'];
                $_SESSION['role']       = $user['role'];
                $_SESSION['first_name'] = $user['first_name'];
                $_SESSION['last_name']  = $user['last_name'];
                $_SESSION['email']      = $user['email'];

                if ($user['password_expired'] == 1) {
                    $_SESSION['password_expired_warning'] = true;
                }

                header('Location: dashboard.php');
                exit;
            } else {
                $error = 'Неверный логин или пароль.';
            }
        } else {
            $error = 'Неверный логин или пароль.';
        }
        $stmt->close();
    } else {
        $error = 'Заполните все поля.';
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Авторизация</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .login-page { min-height: 100vh; display: flex; align-items: center; justify-content: center; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 20px; font-family: sans-serif; }
        .login-container { width: 100%; max-width: 440px; }
        .login-card { background: white; border-radius: 12px; padding: 40px 36px; box-shadow: 0 10px 25px rgba(0,0,0,0.15); }
        .login-header { text-align: center; margin-bottom: 32px; }
        .login-header h1 { font-size: 28px; color: #333; margin-bottom: 8px; }
        .login-header p { color: #777; font-size: 14px; }
        .alert-error { background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.3); color: #ef4444; padding: 10px 14px; border-radius: 6px; font-size: 13px; margin-bottom: 20px; display: flex; align-items: center; gap: 8px; }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; margin-bottom: 8px; font-weight: 500; font-size: 13px; color: #666; }
        .form-group input { width: 100%; padding: 11px 14px; border: 1.5px solid #ddd; border-radius: 6px; font-size: 14px; box-sizing: border-box; }
        .form-group input:focus { outline: none; border-color: #6366f1; }
        .btn-login { width: 100%; padding: 12px; background: linear-gradient(135deg, #6366f1, #4f46e5); color: white; border: none; border-radius: 6px; font-size: 14px; font-weight: 600; cursor: pointer; }
        .btn-login:hover { transform: translateY(-1px); box-shadow: 0 6px 14px rgba(99, 102, 241, 0.35); }

        /* Капча */
        .captcha-row { display: flex; align-items: center; gap: 10px; }
        .captcha-row img { border: 1.5px solid #ddd; border-radius: 6px; cursor: pointer; display: block; }
        .captcha-row input { flex: 1; }
        .captcha-hint { font-size: 11px; color: #999; margin-top: 6px; }
    </style>
</head>
<body class="login-page">
    <div class="login-container">
        <div class="login-card">
            <div class="login-header">
                <h1>Вход в систему</h1>
                <p>Панель управления пользователями</p>
            </div>

            <?php if ($error): ?>
                <div class="alert-error">
                    <i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>

            <form method="post">
                <div class="form-group">
                    <label for="login"><i class="fas fa-user"></i> Логин</label>
                    <input type="text" id="login" name="login"
                           placeholder="Введите логин"
                           value="<?= htmlspecialchars($_POST['login'] ?? '') ?>"
                           required autofocus>
                </div>

                <div class="form-group">
                    <label for="password"><i class="fas fa-lock"></i> Пароль</label>
                    <input type="password" id="password" name="password"
                           placeholder="Введите пароль" required>
                </div>

                <div class="form-group">
                    <label for="captcha"><i class="fas fa-shield-alt"></i> Код с картинки</label>
                    <div class="captcha-row">
                        <img src="captcha.php" alt="Капча"
                             onclick="this.src='captcha.php?' + Math.random()"
                             title="Нажмите, чтобы обновить">
                        <input type="text" id="captcha" name="captcha"
                               maxlength="5" autocomplete="off" required
                               placeholder="Код">
                    </div>
                    <div class="captcha-hint">Нажмите на картинку, чтобы обновить</div>
                </div>

                <button type="submit" class="btn-login">
                    <i class="fas fa-sign-in-alt"></i> Войти в систему
                </button>
            </form>
        </div>
    </div>
</body>
</html>