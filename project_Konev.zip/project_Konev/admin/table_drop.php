<?php
require_once __DIR__ . '/_auth.php';

// Только POST — удаление не должно работать через прямую ссылку
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: tables.php?msg=err_generic');
    exit;
}

$name = trim($_POST['name'] ?? '');

// 1. Имя задано и корректно
if ($name === '' || !is_valid_identifier($name)) {
    header('Location: tables.php?msg=err_name');
    exit;
}

// 2. Не защищённая таблица
if (is_protected_table($name)) {
    header('Location: tables.php?msg=err_protect');
    exit;
}

// 3. Таблица существует в текущей БД
$stmt = $conn->prepare("
    SELECT COUNT(*) AS c
    FROM information_schema.TABLES
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?
");
$stmt->bind_param("s", $name);
$stmt->execute();
$exists = (int)$stmt->get_result()->fetch_assoc()['c'];
$stmt->close();

if ($exists === 0) {
    header('Location: tables.php?msg=err_generic');
    exit;
}

// 4. Удаляем. Имя таблицы экранируем через backticks.
$safeName = '`' . str_replace('`', '``', $name) . '`';

try {
    $conn->query("DROP TABLE $safeName");
    header('Location: tables.php?msg=dropped');
    exit;
} catch (Throwable $e) {
    error_log('table_drop error: ' . $e->getMessage());
    header('Location: tables.php?msg=err_sql');
    exit;
}