<?php

declare(strict_types=1);

require_once __DIR__ . '/_auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: tables.php?msg=err_generic');
    exit;
}

$name = trim($_POST['name'] ?? '');

if ($name === '' || !isValidIdentifier($name)) {
    header('Location: tables.php?msg=err_name');
    exit;
}

if (isProtectedTable($name)) {
    header('Location: tables.php?msg=err_protect');
    exit;
}

$stmt = $conn->prepare("
    SELECT COUNT(*) AS c
    FROM information_schema.TABLES
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?
");
$stmt->bind_param('s', $name);
$stmt->execute();
$exists = (int) $stmt->get_result()->fetch_assoc()['c'];
$stmt->close();

if ($exists === 0) {
    header('Location: tables.php?msg=err_generic');
    exit;
}

$safeName = '`' . str_replace('`', '``', $name) . '`';

try {
    $conn->query("DROP TABLE $safeName");
    header('Location: tables.php?msg=dropped');
    exit;
} catch (Throwable $e) {
    error_log('table_drop error: ' . $e->getMessage());
    header('Location: tables.php?msg=err_sql');
    exit;
}