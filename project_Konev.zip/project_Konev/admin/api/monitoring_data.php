<?php

declare(strict_types=1);

require_once __DIR__ . '/../_auth.php';

// Очищаем буфер, чтобы ничего не сломало JSON
ob_clean();

// --- 1. ДИСК ---
$diskFree  = disk_free_space('/');
$diskTotal = disk_total_space('/');
$diskUsed  = $diskTotal - $diskFree;
$diskPercent = ($diskTotal > 0) ? round(($diskUsed / $diskTotal) * 100, 1) : 0;

// --- 2. ОЗУ ---
$memTotal = 0;
$memFree  = 0;
if (file_exists('/proc/meminfo')) {
    $memInfo = file_get_contents('/proc/meminfo');
    preg_match('/MemTotal:\s+(\d+) kB/', $memInfo, $matchesTotal);
    preg_match('/MemAvailable:\s+(\d+) kB/', $memInfo, $matchesFree);
    if (isset($matchesTotal[1])) {
        $memTotal = round((int)$matchesTotal[1] / 1024 / 1024, 2);
    }
    if (isset($matchesFree[1])) {
        $memFree = round((int)$matchesFree[1] / 1024 / 1024, 2);
    }
}
$memUsed = $memTotal - $memFree;
$memPercent = ($memTotal > 0) ? round(($memUsed / $memTotal) * 100, 1) : 0;

// --- 3. CPU ---
$loadAvg = sys_getloadavg();
$cpuLoad1 = round((float)($loadAvg[0] ?? 0), 2);

$cpuCores = 1;
if (file_exists('/proc/cpuinfo')) {
    $cpuInfo = file_get_contents('/proc/cpuinfo');
    $cpuCores = substr_count($cpuInfo, 'processor');
}
if ($cpuCores < 1) {
    $cpuCores = 1;
}

$cpuPercent = round(($cpuLoad1 / $cpuCores) * 100, 1);
if ($cpuPercent > 100) $cpuPercent = 100;

// --- 4. ВРЕМЯ РАБОТЫ И СТАРТА ---
$uptimeSeconds = 0;
if (file_exists('/proc/uptime')) {
    $uptimeData = explode(' ', file_get_contents('/proc/uptime'));
    $uptimeSeconds = (int)$uptimeData[0];
}

$days = floor($uptimeSeconds / 86400);
$hours = floor(($uptimeSeconds % 86400) / 3600);
$minutes = floor(($uptimeSeconds % 3600) / 60);

$uptimeText = '';
if ($days > 0) $uptimeText .= $days . ' д. ';
if ($hours > 0) $uptimeText .= $hours . ' ч. ';
$uptimeText .= $minutes . ' мин.';

$startTimestamp = time() - $uptimeSeconds;
$startTimeText = date('d.m.Y H:i', $startTimestamp);

// --- 5. СКОРОСТЬ СЕТИ ---
$cacheFile = __DIR__ . '/../../captcha_tmp/net_cache.txt';
$currentRx = 0;
$currentTx = 0;
$netSpeedRx = 0;
$netSpeedTx = 0;

if (file_exists('/proc/net/dev')) {
    $netData = file_get_contents('/proc/net/dev');
    preg_match_all('/:\s+(\d+)\s+\d+\s+\d+\s+\d+\s+\d+\s+\d+\s+\d+\s+\d+\s+(\d+)/', $netData, $matches);
    foreach ($matches[1] as $index => $rx) {
        $currentRx += (int)$rx;
        $currentTx += (int)$matches[2][$index];
    }
    
    if (file_exists($cacheFile)) {
        $cacheData = explode('|', file_get_contents($cacheFile));
        $prevRx = (int)($cacheData[0] ?? 0);
        $prevTx = (int)($cacheData[1] ?? 0);
        $prevTime = (int)($cacheData[2] ?? time());
        
        $timeDiff = time() - $prevTime;
        if ($timeDiff > 0) {
            $netSpeedRx = round(($currentRx - $prevRx) / $timeDiff / 1024, 2);
            $netSpeedTx = round(($currentTx - $prevTx) / $timeDiff / 1024, 2);
        }
    }
    file_put_contents($cacheFile, $currentRx . '|' . $currentTx . '|' . time());
}

// --- 6. БАЗА ДАННЫХ ---
$dbStart = microtime(true);

$dbName = $conn->query("SELECT DATABASE()")->fetch_row()[0] ?? '';

$dbSizeQuery = $conn->prepare("
    SELECT SUM(data_length + index_length) / 1024 / 1024 AS size_mb
    FROM information_schema.TABLES
    WHERE TABLE_SCHEMA = ?
");
$dbSizeQuery->bind_param('s', $dbName);
$dbSizeQuery->execute();
$dbSizeMb = round((float)($dbSizeQuery->get_result()->fetch_assoc()['size_mb'] ?? 0), 2);
$dbSizeQuery->close();

$tablesCount = 0;
$rowsCount = 0;
$tablesQuery = $conn->query("SHOW TABLES");
while ($table = $tablesQuery->fetch_row()) {
    $tablesCount++;
    $tableName = $table[0];
    $countQuery = $conn->query("SELECT COUNT(*) AS c FROM `$tableName`");
    $rowsCount += (int)$countQuery->fetch_assoc()['c'];
}

$dbEnd = microtime(true);
$dbSpeedMs = round(($dbEnd - $dbStart) * 1000, 2);

// --- 7. РАСЧЕТ ФАКТИЧЕСКОЙ ВМЕСТИМОСТИ ---
$usersCountQuery = $conn->query("SELECT COUNT(*) AS c FROM `user`");
$usersCount = (int)$usersCountQuery->fetch_assoc()['c'];
$safeUserCount = max(1, $usersCount);

$freeRamMb = $memFree * 1024;
$maxUsersByRam = (int)($freeRamMb * 0.8 / 15);

$sizePerUserMb = $dbSizeMb / $safeUserCount;
$freeDiskMb = ($diskFree / 1024 / 1024) * 0.5;
$maxUsersByDisk = ($sizePerUserMb > 0) ? (int)($freeDiskMb / ($sizePerUserMb + 10)) : 999999;

$availableCpuLoad = max(0, ($cpuCores * 0.8) - $cpuLoad1); 
$maxUsersByCpu = (int)($availableCpuLoad / 0.01);

$maxCapacity = min($maxUsersByRam, $maxUsersByDisk, $maxUsersByCpu);
if ($maxCapacity < 0) {
    $maxCapacity = 0;
}

$limitingFactor = 'ОЗУ';
if ($maxCapacity === $maxUsersByDisk) $limitingFactor = 'Диск';
if ($maxCapacity === $maxUsersByCpu) $limitingFactor = 'CPU';

// Формируем итоговый массив
$responseData = [
    'generated_at' => date('Y-m-d H:i:s'),
    'system' => [
        'uptime_text' => $uptimeText,
        'start_time' => $startTimeText,
    ],
    'performance' => [
        'db_speed_ms' => $dbSpeedMs,
    ],
    'disk' => [
        'percent' => $diskPercent,
        'used_gb' => round($diskUsed / 1024 / 1024 / 1024, 1),
        'total_gb' => round($diskTotal / 1024 / 1024 / 1024, 1)
    ],
    'ram' => [
        'percent' => $memPercent,
        'used_gb' => $memUsed,
        'total_gb' => $memTotal
    ],
    'cpu' => [
        'percent' => $cpuPercent,
        'cores' => $cpuCores
    ],
    'net' => [
        'rx_kbps' => $netSpeedRx,
        'tx_kbps' => $netSpeedTx
    ],
    'db' => [
        'name' => $dbName,
        'size_mb' => $dbSizeMb,
        'tables' => $tablesCount,
        'rows' => $rowsCount
    ],
    'capacity' => [
        'users_count' => $usersCount,
        'size_per_user_kb' => round($sizePerUserMb * 1024, 1),
        'max_by_ram' => $maxUsersByRam,
        'max_by_disk' => $maxUsersByDisk,
        'max_by_cpu' => $maxUsersByCpu,
        'max_total' => $maxCapacity,
        'limiting_factor' => $limitingFactor
    ]
];

// Если запрошено скачивание файла
if (isset($_GET['download']) && $_GET['download'] === '1') {
    $filename = 'monitoring_report_' . date('Y-m-d_H-i') . '.json';
    header('Content-Description: File Transfer');
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    echo json_encode($responseData, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

// Обычный ответ для JS
header('Content-Type: application/json; charset=utf-8');
echo json_encode($responseData);