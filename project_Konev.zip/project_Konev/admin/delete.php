<?php

declare(strict_types=1);

require_once __DIR__ . '/_auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php?msg=err_generic');
    exit;
}

$id = (int) ($_POST['id'] ?? $_GET['id'] ?? 0);

if ($id <= 0) {
    header('Location: index.php?msg=err_generic');
    exit;
}

if (isSelf($id)) {
    header('Location: index.php?msg=err_self');
    exit;
}

$stmt = $conn->prepare("SELECT id_u, login, role, is_blocked FROM `user` WHERE id_u = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$user) {
    header('Location: index.php?msg=err_generic');
    exit;
}

try {
    $stmt = $conn->prepare("DELETE FROM `user` WHERE id_u = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $stmt->close();

    header('Location: index.php?msg=deleted');
    exit;
} catch (mysqli_sql_exception $e) {
    header('Location: index.php?msg=err_last');
    exit;
}