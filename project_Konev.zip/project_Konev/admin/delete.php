<?php
require_once __DIR__ . '/_auth.php';

// Только POST — чтобы нельзя было удалить через прямую ссылку
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php?msg=err_generic');
    exit;
}

// Принимаем id — из POST или GET (для совместимости со ссылкой в index.php)
$id = (int)($_POST['id'] ?? $_GET['id'] ?? 0);

if ($id <= 0) {
    header('Location: index.php?msg=err_generic');
    exit;
}

// 1. Нельзя удалить себя
if (is_self($id)) {
    header('Location: index.php?msg=err_self');
    exit;
}

// 2. Проверяем, что пользователь существует
$stmt = $conn->prepare("SELECT id_u, login, role, is_blocked FROM `user` WHERE id_u = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$user) {
    header('Location: index.php?msg=err_generic');
    exit;
}

// 3. Удаляем. Триггер сам проверит «последнего активного sysadmin».
try {
    $stmt = $conn->prepare("DELETE FROM `user` WHERE id_u = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();

    header('Location: index.php?msg=deleted');
    exit;
} catch (mysqli_sql_exception $e) {
    // Триггер SIGNAL SQLSTATE '45000'
    header('Location: index.php?msg=err_last');
    exit;
}