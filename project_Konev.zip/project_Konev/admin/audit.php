<?php
require_once __DIR__ . '/_auth.php';

$pageTitle  = 'Админ-панель — Журнал аудита';
$activeMenu = 'audit';

// --- Параметры ---
$userId = (int)($_GET['user_id'] ?? 0);
$action = trim($_GET['action'] ?? '');
$dateFrom = trim($_GET['date_from'] ?? '');
$dateTo   = trim($_GET['date_to'] ?? '');
$page     = max(1, (int)($_GET['page'] ?? 1));
$perPage  = 20;
$offset   = ($page - 1) * $perPage;

// --- WHERE ---
$where  = [];
$params = [];
$types  = '';

if ($userId > 0) {
    $where[]  = "a.id_u = ?";
    $params[] = $userId;
    $types   .= 'i';
}
if (in_array($action, ['role_changed', 'blocked', 'unblocked'], true)) {
    $where[]  = "a.action = ?";
    $params[] = $action;
    $types   .= 's';
}
if ($dateFrom !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateFrom)) {
    $where[]  = "DATE(a.changed_at) >= ?";
    $params[] = $dateFrom;
    $types   .= 's';
}
if ($dateTo !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateTo)) {
    $where[]  = "DATE(a.changed_at) <= ?";
    $params[] = $dateTo;
    $types   .= 's';
}

$whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

// --- Общее количество ---
$stmt = $conn->prepare("SELECT COUNT(*) AS c FROM `user_audit` a $whereSql");
if ($params) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$totalRows = (int)$stmt->get_result()->fetch_assoc()['c'];
$stmt->close();

$totalPages = max(1, (int)ceil($totalRows / $perPage));

// --- Записи текущей страницы ---
// LEFT JOIN user, чтобы показать логин даже для удалённых (если есть совпадение)
$sql = "
    SELECT
        a.audit_id, a.id_u, a.action, a.old_value, a.new_value,
        a.changed_by, a.changed_at,
        u.login, u.last_name, u.first_name
    FROM `user_audit` a
    LEFT JOIN `user` u ON u.id_u = a.id_u
    $whereSql
    ORDER BY a.changed_at DESC, a.audit_id DESC
    LIMIT ? OFFSET ?
";
$stmt = $conn->prepare($sql);
$paramsWithLimit = $params;
$paramsWithLimit[] = $perPage;
$paramsWithLimit[] = $offset;
$typesWithLimit = $types . 'ii';
$stmt->bind_param($typesWithLimit, ...$paramsWithLimit);
$stmt->execute();
$records = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// --- Список пользователей для фильтра (включая тех, кто уже удалён) ---
$userList = $conn->query("
    SELECT DISTINCT a.id_u, u.login, u.last_name, u.first_name
    FROM `user_audit` a
    LEFT JOIN `user` u ON u.id_u = a.id_u
    ORDER BY a.id_u ASC
")->fetch_all(MYSQLI_ASSOC);

// --- Хелпер для ссылки с сохранением фильтров ---
function qs(array $extra = []): string {
    $base = [
        'user_id'   => $_GET['user_id']   ?? '',
        'action'    => $_GET['action']    ?? '',
        'date_from' => $_GET['date_from'] ?? '',
        'date_to'   => $_GET['date_to']   ?? '',
        'page'      => $_GET['page']      ?? '',
    ];
    foreach ($extra as $k => $v) {
        $base[$k] = $v;
    }
    $base = array_filter($base, fn($v) => $v !== '' && $v !== null);
    return http_build_query($base);
}

require __DIR__ . '/_header.php';
?>

<?php if (isset($_GET['msg'])): ?>
    <div class="alert alert-success">
        <?= h($_GET['msg']) ?>
    </div>
<?php endif; ?>

<div class="stats">
    <div class="stat"><div class="num"><?= $totalRows ?></div><div class="lbl">Записей аудита</div></div>
    <div class="stat">
        <div class="num">
            <?php
            $cnt = $conn->query("SELECT COUNT(*) AS c FROM `user_audit` WHERE action = 'role_changed'")->fetch_assoc()['c'];
            echo (int)$cnt;
            ?>
        </div>
        <div class="lbl">Смен ролей</div>
    </div>
    <div class="stat">
        <div class="num">
            <?php
            $cnt = $conn->query("SELECT COUNT(*) AS c FROM `user_audit` WHERE action = 'blocked'")->fetch_assoc()['c'];
            echo (int)$cnt;
            ?>
        </div>
        <div class="lbl">Блокировок</div>
    </div>
    <div class="stat">
        <div class="num">
            <?php
            $cnt = $conn->query("SELECT COUNT(*) AS c FROM `user_audit` WHERE action = 'unblocked'")->fetch_assoc()['c'];
            echo (int)$cnt;
            ?>
        </div>
        <div class="lbl">Разблокировок</div>
    </div>
</div>

<form class="filters" method="get">
    <select name="user_id">
        <option value="">Все пользователи</option>
        <?php foreach ($userList as $u): ?>
            <?php
            $label = $u['login']
                ? ($u['last_name'] . ' ' . $u['first_name'] . ' (' . $u['login'] . ')')
                : ('id ' . $u['id_u'] . ' (удалён)');
            ?>
            <option value="<?= (int)$u['id_u'] ?>" <?= $userId === (int)$u['id_u'] ? 'selected' : '' ?>>
                <?= h($label) ?>
            </option>
        <?php endforeach; ?>
    </select>

    <select name="action">
        <option value="">Все действия</option>
        <option value="role_changed" <?= $action === 'role_changed' ? 'selected' : '' ?>>Смена роли</option>
        <option value="blocked"      <?= $action === 'blocked'      ? 'selected' : '' ?>>Блокировка</option>
        <option value="unblocked"    <?= $action === 'unblocked'    ? 'selected' : '' ?>>Разблокировка</option>
    </select>

    <input type="date" name="date_from" value="<?= h($dateFrom) ?>" title="Дата от">
    <input type="date" name="date_to"   value="<?= h($dateTo) ?>"   title="Дата до">

    <button type="submit" class="btn btn-primary">Фильтр</button>
    <a href="audit.php" class="btn btn-secondary">Сбросить</a>
</form>

<table>
    <thead>
        <tr>
            <th>id</th>
            <th>Когда</th>
            <th>Пользователь</th>
            <th>Действие</th>
            <th>Было</th>
            <th>Стало</th>
            <th>Кто изменил</th>
        </tr>
    </thead>
    <tbody>
    <?php if (empty($records)): ?>
        <tr>
            <td colspan="7" style="text-align:center; color:#888; padding:30px;">
                Записей не найдено
            </td>
        </tr>
    <?php else: ?>
        <?php foreach ($records as $r): ?>
            <tr>
                <td><?= (int)$r['audit_id'] ?></td>
                <td><?= h($r['changed_at']) ?></td>
                <td>
                    <?php if ($r['login']): ?>
                        <?= h($r['last_name'] . ' ' . $r['first_name']) ?>
                        <span style="color:#888;">(<?= h($r['login']) ?>)</span>
                    <?php else: ?>
                        <span style="color:#888;">
                            id <?= (int)$r['id_u'] ?> — удалён
                        </span>
                    <?php endif; ?>
                </td>
                <td>
                    <?php
                    $labels = [
                        'role_changed' => 'Смена роли',
                        'blocked'      => 'Блокировка',
                        'unblocked'    => 'Разблокировка',
                    ];
                    $cls = [
                        'role_changed' => 'tag tag-admin',
                        'blocked'      => 'tag tag-blocked',
                        'unblocked'    => 'tag tag-active',
                    ];
                    ?>
                    <span class="<?= h($cls[$r['action']] ?? 'tag') ?>">
                        <?= h($labels[$r['action']] ?? $r['action']) ?>
                    </span>
                </td>
                <td><?= h($r['old_value']) ?></td>
                <td><?= h($r['new_value']) ?></td>
                <td><code style="font-size:11px;"><?= h($r['changed_by']) ?></code></td>
            </tr>
        <?php endforeach; ?>
    <?php endif; ?>
    </tbody>
</table>

<?php if ($totalPages > 1): ?>
    <div class="pagination">
        <?php if ($page > 1): ?>
            <a href="?<?= qs(['page' => $page - 1]) ?>">← Назад</a>
        <?php else: ?>
            <span class="disabled">← Назад</span>
        <?php endif; ?>

        <?php
        $start = max(1, $page - 2);
        $end   = min($totalPages, $page + 2);
        if ($start > 1) {
            echo '<a href="?' . qs(['page' => 1]) . '">1</a>';
            if ($start > 2) echo '<span>…</span>';
        }
        for ($i = $start; $i <= $end; $i++) {
            if ($i === $page) {
                echo '<span class="current">' . $i . '</span>';
            } else {
                echo '<a href="?' . qs(['page' => $i]) . '">' . $i . '</a>';
            }
        }
        if ($end < $totalPages) {
            if ($end < $totalPages - 1) echo '<span>…</span>';
            echo '<a href="?' . qs(['page' => $totalPages]) . '">' . $totalPages . '</a>';
        }
        ?>

        <?php if ($page < $totalPages): ?>
            <a href="?<?= qs(['page' => $page + 1]) ?>">Вперёд →</a>
        <?php else: ?>
            <span class="disabled">Вперёд →</span>
        <?php endif; ?>
    </div>
<?php endif; ?>

<?php require __DIR__ . '/_footer.php'; ?>