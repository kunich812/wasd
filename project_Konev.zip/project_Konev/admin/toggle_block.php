<?php

declare(strict_types=1);

require_once __DIR__ . '/_auth.php';

$id = (int) ($_GET['id'] ?? 0);
if ($id <= 0) {
    header('Location: index.php?msg=err_generic');
    exit;
}

if (isSelf($id)) {
    header('Location: index.php?msg=err_self');
    exit;
}

$stmt = $conn->prepare("SELECT id_u, login, role, is_blocked FROM `user` WHERE id_u = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$user) {
    header('Location: index.php?msg=err_generic');
    exit;
}

$newStatus = $user['is_blocked'] === 'да' ? 'нет' : 'да';

try {
    $stmt = $conn->prepare("UPDATE `user` SET is_blocked = ? WHERE id_u = ?");
    $stmt->bind_param('si', $newStatus, $id);
    $stmt->execute();
    $stmt->close();

    $msg = $newStatus === 'да' ? 'blocked' : 'unblocked';
    header("Location: index.php?msg=$msg");
    exit;
} catch (mysqli_sql_exception $e) {
    header('Location: index.php?msg=err_last');
    exit;
}