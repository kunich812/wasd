<?php
require_once __DIR__ . '/_auth.php';

// Только GET с параметром id
$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header('Location: index.php?msg=err_generic');
    exit;
}

// 1. Нельзя блокировать себя
if (is_self($id)) {
    header('Location: index.php?msg=err_self');
    exit;
}

// 2. Получаем пользователя
$stmt = $conn->prepare("SELECT id_u, login, role, is_blocked FROM `user` WHERE id_u = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$user) {
    header('Location: index.php?msg=err_generic');
    exit;
}

$newStatus = $user['is_blocked'] === 'да' ? 'нет' : 'да';

// 3. Триггер сам проверит: нельзя заблокировать последнего активного sysadmin.
//    Но мы можем дать более понятное сообщение — ловим ошибку.
try {
    $stmt = $conn->prepare("UPDATE `user` SET is_blocked = ? WHERE id_u = ?");
    $stmt->bind_param("si", $newStatus, $id);
    $stmt->execute();
    $stmt->close();

    $msg = $newStatus === 'да' ? 'blocked' : 'unblocked';
    header("Location: index.php?msg=$msg");
    exit;
} catch (mysqli_sql_exception $e) {
    // Триггер бросил SIGNAL SQLSTATE '45000'
    header('Location: index.php?msg=err_last');
    exit;
}