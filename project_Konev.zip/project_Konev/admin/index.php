<?php

declare(strict_types=1);

require_once __DIR__ . '/_auth.php';

$pageTitle  = 'Админ-панель — Пользователи';
$activeMenu = 'users';

$search = trim($_GET['search'] ?? '');
$role   = trim($_GET['role'] ?? '');
$status = trim($_GET['status'] ?? '');
$page   = max(1, (int) ($_GET['page'] ?? 1));
$perPage = 10;
$offset  = ($page - 1) * $perPage;

$where  = [];
$params = [];
$types  = '';

if ($search !== '') {
    $where[] = "(login LIKE ? OR email LIKE ? OR last_name LIKE ? OR first_name LIKE ? OR phone LIKE ?)";
    $like = "%$search%";
    for ($i = 0; $i < 5; $i++) {
        $params[] = $like;
        $types   .= 's';
    }
}

if ($role !== '' && in_array($role, ['sysadmin', 'admin', 'user'], true)) {
    $where[]  = "role = ?";
    $params[] = $role;
    $types   .= 's';
}

if ($status === 'нет' || $status === 'да') {
    $where[]  = "is_blocked = ?";
    $params[] = $status;
    $types   .= 's';
}

$whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

$sqlCount = "SELECT COUNT(*) AS cnt FROM `user` $whereSql";
$stmt = $conn->prepare($sqlCount);
if ($params) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$totalRows = (int) $stmt->get_result()->fetch_assoc()['cnt'];
$stmt->close();

$totalPages = max(1, (int) ceil($totalRows / $perPage));

$sql = "SELECT id_u, last_name, first_name, middle_name, email, login, phone, role, is_blocked, password_created_at
        FROM `user`
        $whereSql
        ORDER BY id_u ASC
        LIMIT ? OFFSET ?";

$stmt = $conn->prepare($sql);
$paramsWithLimit = $params;
$paramsWithLimit[] = $perPage;
$paramsWithLimit[] = $offset;
$typesWithLimit = $types . 'ii';
$stmt->bind_param($typesWithLimit, ...$paramsWithLimit);
$stmt->execute();
$users = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$stats = $conn->query("
    SELECT
        COUNT(*) AS total,
        SUM(is_blocked = 'нет') AS active,
        SUM(is_blocked = 'да') AS blocked,
        SUM(role = 'sysadmin') AS cnt_sysadmin,
        SUM(role = 'admin') AS cnt_admin,
        SUM(role = 'user') AS cnt_user
    FROM `user`
")->fetch_assoc();

function qs(array $extra = []): string
{
    $base = [
        'search' => $_GET['search'] ?? '',
        'role'   => $_GET['role'] ?? '',
        'status' => $_GET['status'] ?? '',
        'page'   => $_GET['page'] ?? '',
    ];
    foreach ($extra as $k => $v) {
        $base[$k] = $v;
    }
    $base = array_filter($base, fn($v) => $v !== '' && $v !== null);
    return http_build_query($base);
}

require __DIR__ . '/_header.php';
?>

<div class="stats">
    <div class="stat"><div class="num"><?= (int) $stats['total'] ?></div><div class="lbl">Всего</div></div>
    <div class="stat"><div class="num"><?= (int) $stats['active'] ?></div><div class="lbl">Активных</div></div>
    <div class="stat"><div class="num"><?= (int) $stats['blocked'] ?></div><div class="lbl">Заблокировано</div></div>
    <div class="stat"><div class="num"><?= (int) $stats['cnt_sysadmin'] ?></div><div class="lbl">Sysadmin</div></div>
    <div class="stat"><div class="num"><?= (int) $stats['cnt_admin'] ?></div><div class="lbl">Admin</div></div>
    <div class="stat"><div class="num"><?= (int) $stats['cnt_user'] ?></div><div class="lbl">User</div></div>
</div>

<?php if (isset($_GET['msg'])) : ?>
    <?php $msg = $_GET['msg']; ?>
    <div class="alert alert-<?= str_starts_with($msg, 'err_') ? 'error' : 'success' ?>">
        <?php
        $messages = [
            'created'      => 'Пользователь успешно создан.',
            'updated'      => 'Пользователь обновлён.',
            'deleted'      => 'Пользователь удалён.',
            'blocked'      => 'Пользователь заблокирован.',
            'unblocked'    => 'Пользователь разблокирован.',
            'password_set' => 'Пароль пользователя сброшен.',
            'bulk_done'    => 'Массовая операция выполнена.',
            'err_self'     => 'Нельзя выполнить операцию над самим собой.',
            'err_last'     => 'Нельзя изменить последнего активного системного администратора.',
            'err_generic'  => 'Не удалось выполнить операцию.',
        ];
        echo h($messages[$msg] ?? 'Операция выполнена.');
        ?>
    </div>
<?php endif; ?>

<form class="filters" method="get">
    <input type="text" name="search" placeholder="Поиск по ФИО, логину, email, телефону"
           value="<?= h($search) ?>" style="flex:1; min-width:220px;">
    <select name="role">
        <option value="">Все роли</option>
        <option value="sysadmin" <?= $role === 'sysadmin' ? 'selected' : '' ?>>sysadmin</option>
        <option value="admin" <?= $role === 'admin' ? 'selected' : '' ?>>admin</option>
        <option value="user" <?= $role === 'user' ? 'selected' : '' ?>>user</option>
    </select>
    <select name="status">
        <option value="">Все статусы</option>
        <option value="нет" <?= $status === 'нет' ? 'selected' : '' ?>>Активные</option>
        <option value="да" <?= $status === 'да' ? 'selected' : '' ?>>Заблокированные</option>
    </select>
    <button type="submit" class="btn btn-primary">Фильтр</button>
    <a href="index.php" class="btn btn-secondary">Сбросить</a>
    <a href="create.php" class="btn btn-success" style="margin-left:auto;">
        <i class="fas fa-plus"></i> Создать пользователя
    </a>
</form>

<form method="post" action="bulk.php" id="bulkForm">
    <div class="bulk-bar">
        <span id="selectedCount">Выбрано: 0</span>
        <select name="action" required>
            <option value="">— Действие —</option>
            <option value="block">Заблокировать</option>
            <option value="unblock">Разблокировать</option>
            <option value="role_sysadmin">Сделать sysadmin</option>
            <option value="role_admin">Сделать admin</option>
            <option value="role_user">Сделать user</option>
            <option value="delete">Удалить</option>
        </select>
        <button type="submit" class="btn btn-warning"
                onclick="return confirm('Применить действие к выбранным пользователям?')">
            Применить
        </button>
    </div>

    <table>
        <thead>
            <tr>
                <th style="width:30px;"><input type="checkbox" id="checkAll"></th>
                <th>id</th>
                <th>ФИО</th>
                <th>Логин</th>
                <th>Email</th>
                <th>Телефон</th>
                <th>Роль</th>
                <th>Статус</th>
                <th>Пароль с</th>
                <th style="width:220px;">Действия</th>
            </tr>
        </thead>
        <tbody>
        <?php if (empty($users)) : ?>
            <tr>
                <td colspan="10" style="text-align:center; color:#888; padding:30px;">
                    Пользователи не найдены
                </td>
            </tr>
        <?php else : ?>
            <?php foreach ($users as $u) : ?>
                <tr>
                    <td><input type="checkbox" name="ids[]" value="<?= (int) $u['id_u'] ?>" class="rowCheck"></td>
                    <td><?= (int) $u['id_u'] ?></td>
                    <td>
                        <?= h($u['last_name']) ?>
                        <?= h($u['first_name']) ?>
                        <?= h($u['middle_name'] ?? '') ?>
                    </td>
                    <td><?= h($u['login']) ?></td>
                    <td><?= h($u['email']) ?></td>
                    <td><?= h($u['phone']) ?></td>
                    <td><span class="tag tag-<?= h($u['role']) ?>"><?= h($u['role']) ?></span></td>
                    <td>
                        <?php if ($u['is_blocked'] === 'да') : ?>
                            <span class="tag tag-blocked">заблокирован</span>
                        <?php else : ?>
                            <span class="tag tag-active">активен</span>
                        <?php endif; ?>
                    </td>
                    <td><?= h($u['password_created_at']) ?></td>
                    <td>
                        <a href="edit.php?id=<?= (int) $u['id_u'] ?>" class="btn btn-sm btn-secondary" title="Редактировать">
                            <i class="fas fa-pen"></i>
                        </a>
                        <a href="reset_password.php?id=<?= (int) $u['id_u'] ?>" class="btn btn-sm btn-warning" title="Сбросить пароль"
                           onclick="return confirm('Сбросить пароль пользователю <?= h($u['login']) ?>?')">
                            <i class="fas fa-key"></i>
                        </a>

                        <?php if (isSelf($u['id_u'])) : ?>
                            <span class="btn btn-sm btn-secondary" style="opacity:.4; cursor:not-allowed;" title="Нельзя изменить себя">
                                <i class="fas fa-lock"></i>
                            </span>
                            <span class="btn btn-sm btn-secondary" style="opacity:.4; cursor:not-allowed;" title="Нельзя удалить себя">
                                <i class="fas fa-trash"></i>
                            </span>
                        <?php else : ?>
                            <a href="toggle_block.php?id=<?= (int) $u['id_u'] ?>"
                               class="btn btn-sm <?= $u['is_blocked'] === 'да' ? 'btn-success' : 'btn-warning' ?>"
                               title="<?= $u['is_blocked'] === 'да' ? 'Разблокировать' : 'Заблокировать' ?>"
                               onclick="return confirm('Изменить статус блокировки?')">
                                <i class="fas fa-<?= $u['is_blocked'] === 'да' ? 'unlock' : 'ban' ?>"></i>
                            </a>
                            <a href="delete.php?id=<?= (int) $u['id_u'] ?>" class="btn btn-sm btn-danger" title="Удалить"
                               onclick="return confirm('Удалить пользователя <?= h($u['login']) ?>? Это действие необратимо.')">
                                <i class="fas fa-trash"></i>
                            </a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
</form>

<?php if ($totalPages > 1) : ?>
    <div class="pagination">
        <?php if ($page > 1) : ?>
            <a href="?<?= qs(['page' => $page - 1]) ?>">← Назад</a>
        <?php else : ?>
            <span class="disabled">← Назад</span>
        <?php endif; ?>

        <?php
        $start = max(1, $page - 2);
        $end   = min($totalPages, $page + 2);
        if ($start > 1) {
            echo '<a href="?' . qs(['page' => 1]) . '">1</a>';
            if ($start > 2) {
                echo '<span>…</span>';
            }
        }
        for ($i = $start; $i <= $end; $i++) {
            if ($i === $page) {
                echo '<span class="current">' . $i . '</span>';
            } else {
                echo '<a href="?' . qs(['page' => $i]) . '">' . $i . '</a>';
            }
        }
        if ($end < $totalPages) {
            if ($end < $totalPages - 1) {
                echo '<span>…</span>';
            }
            echo '<a href="?' . qs(['page' => $totalPages]) . '">' . $totalPages . '</a>';
        }
        ?>

        <?php if ($page < $totalPages) : ?>
            <a href="?<?= qs(['page' => $page + 1]) ?>">Вперёд →</a>
        <?php else : ?>
            <span class="disabled">Вперёд →</span>
        <?php endif; ?>
    </div>
<?php endif; ?>

<script>
    const checkAll = document.getElementById('checkAll');
    const rowChecks = document.querySelectorAll('.rowCheck');
    const counter  = document.getElementById('selectedCount');

    function updateCount() {
        const n = document.querySelectorAll('.rowCheck:checked').length;
        counter.textContent = 'Выбрано: ' + n;
    }

    if (checkAll) {
        checkAll.addEventListener('change', () => {
            rowChecks.forEach(cb => cb.checked = checkAll.checked);
            updateCount();
        });
    }
    rowChecks.forEach(cb => cb.addEventListener('change', updateCount));
</script>

<?php require __DIR__ . '/_footer.php'; ?>