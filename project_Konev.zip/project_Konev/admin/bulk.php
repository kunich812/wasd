<?php
require_once __DIR__ . '/_auth.php';

// Только POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php?msg=err_generic');
    exit;
}

$action = $_POST['action'] ?? '';
$ids    = $_POST['ids']    ?? [];

if (!is_array($ids) || empty($ids) || $action === '') {
    header('Location: index.php?msg=err_generic');
    exit;
}

// Приводим к int и убираем дубликаты
$ids = array_values(array_unique(array_map('intval', $ids)));
$ids = array_filter($ids, fn($v) => $v > 0);

if (empty($ids)) {
    header('Location: index.php?msg=err_generic');
    exit;
}

// Убираем свой id — нельзя массово менять себя
$selfId  = (int)$_SESSION['user_id'];
$selfWas = in_array($selfId, $ids, true);
$ids     = array_values(array_filter($ids, fn($v) => $v !== $selfId));

if (empty($ids)) {
    // Все id — это мы сами
    header('Location: index.php?msg=err_self');
    exit;
}

$done = 0;   // успешных операций
$skip = 0;   // пропущено из-за ограничений

$in = implode(',', array_fill(0, count($ids), '?'));

foreach ($ids as $id) {
    try {
        switch ($action) {
            case 'block':
            case 'unblock':
                $newStatus = $action === 'block' ? 'да' : 'нет';
                $stmt = $conn->prepare("UPDATE `user` SET is_blocked = ? WHERE id_u = ?");
                $stmt->bind_param("si", $newStatus, $id);
                $stmt->execute();
                $stmt->close();
                $done++;
                break;

            case 'role_sysadmin':
            case 'role_admin':
            case 'role_user':
                $newRole = str_replace('role_', '', $action);

                // Защита: нельзя понизить последнего активного sysadmin
                $stmt = $conn->prepare("SELECT role, is_blocked FROM `user` WHERE id_u = ?");
                $stmt->bind_param("i", $id);
                $stmt->execute();
                $u = $stmt->get_result()->fetch_assoc();
                $stmt->close();

                if (!$u) { $skip++; break; }

                if ($u['role'] === 'sysadmin' && $u['is_blocked'] === 'нет'
                    && $newRole !== 'sysadmin') {
                    $cnt = (int)$conn->query("
                        SELECT COUNT(*) AS c FROM `user`
                        WHERE role = 'sysadmin' AND is_blocked = 'нет'
                    ")->fetch_assoc()['c'];

                    if ($cnt <= 1) {
                        $skip++;
                        break;
                    }
                }

                $stmt = $conn->prepare("UPDATE `user` SET role = ? WHERE id_u = ?");
                $stmt->bind_param("si", $newRole, $id);
                $stmt->execute();
                $stmt->close();
                $done++;
                break;

            case 'delete':
                // Нельзя удалять себя — уже отфильтровано выше
                $stmt = $conn->prepare("DELETE FROM `user` WHERE id_u = ?");
                $stmt->bind_param("i", $id);
                $stmt->execute();
                $stmt->close();
                $done++;
                break;

            default:
                header('Location: index.php?msg=err_generic');
                exit;
        }
    } catch (mysqli_sql_exception $e) {
        // Триггер заблокировал операцию (например, последний sysadmin)
        $skip++;
    }
}

header('Location: index.php?msg=bulk_done');
exit;