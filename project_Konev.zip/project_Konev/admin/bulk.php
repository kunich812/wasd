<?php

declare(strict_types=1);

require_once __DIR__ . '/_auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php?msg=err_generic');
    exit;
}

$action = $_POST['action'] ?? '';
$ids    = $_POST['ids'] ?? [];

if (!is_array($ids) || empty($ids) || $action === '') {
    header('Location: index.php?msg=err_generic');
    exit;
}

$ids = array_values(array_unique(array_map('intval', $ids)));
$ids = array_filter($ids, fn($v) => $v > 0);

if (empty($ids)) {
    header('Location: index.php?msg=err_generic');
    exit;
}

$selfId  = (int) $_SESSION['user_id'];
$ids     = array_values(array_filter($ids, fn($v) => $v !== $selfId));

if (empty($ids)) {
    header('Location: index.php?msg=err_self');
    exit;
}

foreach ($ids as $id) {
    try {
        switch ($action) {
            case 'block':
            case 'unblock':
                $newStatus = $action === 'block' ? 'да' : 'нет';
                $stmt = $conn->prepare("UPDATE `user` SET is_blocked = ? WHERE id_u = ?");
                $stmt->bind_param('si', $newStatus, $id);
                $stmt->execute();
                $stmt->close();
                break;

            case 'role_sysadmin':
            case 'role_admin':
            case 'role_user':
                $newRole = str_replace('role_', '', $action);

                $stmt = $conn->prepare("SELECT role, is_blocked FROM `user` WHERE id_u = ?");
                $stmt->bind_param('i', $id);
                $stmt->execute();
                $u = $stmt->get_result()->fetch_assoc();
                $stmt->close();

                if (!$u) {
                    break;
                }

                if ($u['role'] === 'sysadmin' && $u['is_blocked'] === 'нет' && $newRole !== 'sysadmin') {
                    $cnt = (int) $conn->query("
                        SELECT COUNT(*) AS c FROM `user`
                        WHERE role = 'sysadmin' AND is_blocked = 'нет'
                    ")->fetch_assoc()['c'];

                    if ($cnt <= 1) {
                        break;
                    }
                }

                $stmt = $conn->prepare("UPDATE `user` SET role = ? WHERE id_u = ?");
                $stmt->bind_param('si', $newRole, $id);
                $stmt->execute();
                $stmt->close();
                break;

            case 'delete':
                $stmt = $conn->prepare("DELETE FROM `user` WHERE id_u = ?");
                $stmt->bind_param('i', $id);
                $stmt->execute();
                $stmt->close();
                break;

            default:
                header('Location: index.php?msg=err_generic');
                exit;
        }
    } catch (mysqli_sql_exception $e) {
        // Пропускаем, если триггер заблокировал операцию
    }
}

header('Location: index.php?msg=bulk_done');
exit;