<?php
require_once __DIR__ . '/_auth.php';

$pageTitle  = 'Админ-панель — Просмотр таблицы';
$activeMenu = 'tables';

// Имя таблицы из GET
$name = trim($_GET['name'] ?? '');

// Проверки
if ($name === '' || !is_valid_identifier($name)) {
    header('Location: tables.php?msg=err_generic');
    exit;
}

// Проверяем, что таблица реально существует в текущей БД
$stmt = $conn->prepare("
    SELECT TABLE_NAME
    FROM information_schema.TABLES
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?
");
$stmt->bind_param("s", $name);
$stmt->execute();
$exists = (bool)$stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$exists) {
    header('Location: tables.php?msg=err_generic');
    exit;
}

// Пагинация
$page    = max(1, (int)($_GET['page'] ?? 1));
$perPage = 100;
$offset  = ($page - 1) * $perPage;

// Экранируем имя таблицы для безопасной подстановки
$safeName = '`' . str_replace('`', '``', $name) . '`';

// Общее количество строк
$totalRows = (int)$conn->query("SELECT COUNT(*) AS c FROM $safeName")->fetch_assoc()['c'];
$totalPages = max(1, (int)ceil($totalRows / $perPage));

// Получаем строки
$result = $conn->query("SELECT * FROM $safeName LIMIT $perPage OFFSET $offset");
if ($result === false) {
    header('Location: tables.php?msg=err_sql');
    exit;
}

$rows = $result->fetch_all(MYSQLI_ASSOC);
$columns = [];
if (!empty($rows)) {
    $columns = array_keys($rows[0]);
}

// Хелпер для сокращения длинных значений
function shortValue(mixed $v, int $max = 200): string {
    $s = (string)$v;
    if (mb_strlen($s) > $max) {
        return mb_substr($s, 0, $max) . '…';
    }
    return $s;
}

// Хелпер для URL с сохранением имени таблицы
function qs(array $extra = []): string {
    $base = ['name' => $_GET['name'] ?? '', 'page' => $_GET['page'] ?? ''];
    foreach ($extra as $k => $v) {
        $base[$k] = $v;
    }
    $base = array_filter($base, fn($v) => $v !== '' && $v !== null);
    return http_build_query($base);
}

require __DIR__ . '/_header.php';
?>

<div class="stats">
    <div class="stat"><div class="num"><?= $totalRows ?></div><div class="lbl">Строк всего</div></div>
    <div class="stat"><div class="num"><?= count($columns) ?></div><div class="lbl">Колонок</div></div>
    <div class="stat"><div class="num"><?= $page ?> / <?= $totalPages ?></div><div class="lbl">Страница</div></div>
    <div class="stat"><div class="num"><code><?= h($name) ?></code></div><div class="lbl">Таблица</div></div>
</div>

<?php if (is_protected_table($name)): ?>
    <div class="alert alert-info">
        <i class="fas fa-info-circle"></i>
        Это защищённая таблица. Просмотр разрешён, но удаление — запрещено.
    </div>
<?php endif; ?>

<div class="filters" style="justify-content: space-between;">
    <a href="tables.php" class="btn btn-secondary">← Назад к таблицам</a>
    <span style="color:#666; font-size:13px;">
        Показаны строки <strong><?= $offset + 1 ?></strong>–<strong><?= min($offset + $perPage, $totalRows) ?></strong>
        из <strong><?= $totalRows ?></strong>
    </span>
</div>

<?php if (empty($rows)): ?>
    <div class="card" style="text-align:center; color:#888; padding:40px;">
        <i class="fas fa-inbox" style="font-size:32px; color:#ccc;"></i>
        <p style="margin-top:12px;">Таблица пуста</p>
    </div>
<?php else: ?>
    <div style="overflow-x:auto;">
        <table>
            <thead>
                <tr>
                    <?php foreach ($columns as $col): ?>
                        <th><code><?= h($col) ?></code></th>
                    <?php endforeach; ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($rows as $row): ?>
                    <tr>
                        <?php foreach ($columns as $col): ?>
                            <?php $val = $row[$col]; ?>
                            <td title="<?= h((string)$val) ?>">
                                <?php if ($val === null): ?>
                                    <span style="color:#aaa; font-style:italic;">NULL</span>
                                <?php else: ?>
                                    <?= h(shortValue($val)) ?>
                                <?php endif; ?>
                            </td>
                        <?php endforeach; ?>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <?php if ($totalPages > 1): ?>
        <div class="pagination">
            <?php if ($page > 1): ?>
                <a href="?<?= qs(['page' => $page - 1]) ?>">← Назад</a>
            <?php else: ?>
                <span class="disabled">← Назад</span>
            <?php endif; ?>

            <?php
            $start = max(1, $page - 2);
            $end   = min($totalPages, $page + 2);
            if ($start > 1) {
                echo '<a href="?' . qs(['page' => 1]) . '">1</a>';
                if ($start > 2) echo '<span>…</span>';
            }
            for ($i = $start; $i <= $end; $i++) {
                if ($i === $page) {
                    echo '<span class="current">' . $i . '</span>';
                } else {
                    echo '<a href="?' . qs(['page' => $i]) . '">' . $i . '</a>';
                }
            }
            if ($end < $totalPages) {
                if ($end < $totalPages - 1) echo '<span>…</span>';
                echo '<a href="?' . qs(['page' => $totalPages]) . '">' . $totalPages . '</a>';
            }
            ?>

            <?php if ($page < $totalPages): ?>
                <a href="?<?= qs(['page' => $page + 1]) ?>">Вперёд →</a>
            <?php else: ?>
                <span class="disabled">Вперёд →</span>
            <?php endif; ?>
        </div>
    <?php endif; ?>
<?php endif; ?>

<?php require __DIR__ . '/_footer.php'; ?>