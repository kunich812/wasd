<?php

declare(strict_types=1);

require_once __DIR__ . '/_auth.php';

// Увеличиваем лимит времени выполнения скрипта
set_time_limit(120);

// --- ЗАПУСК ТЕСТА (AJAX) ---
if (isset($_GET['ajax']) && $_GET['ajax'] === '1') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    
    $scriptPath = __DIR__ . '/run_test.py';
    $reportFile = __DIR__ . '/selenium_report.json';
    $lockFile   = __DIR__ . '/selenium_running.lock';
    
    if (file_exists($reportFile)) {
        unlink($reportFile);
    }
    if (file_exists($lockFile)) {
        unlink($lockFile);
    }

    // Создаем lock-файл
    file_put_contents($lockFile, 'running');
    
    $pythonCmd = (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') ? 'python' : 'python3';
    
    // Запуск в фоне (Linux). Для Windows используется другой синтаксис, но на сервере это обычно Linux.
    $command = $pythonCmd . " " . escapeshellarg($scriptPath) . " > /dev/null 2>&1 &";
    shell_exec($command);
    
    echo json_encode(['success' => true, 'log' => 'Процесс тестирования запущен в фоне.']);
    exit;
}

// --- ПРОВЕРКА СТАТУСА (AJAX) ---
if (isset($_GET['status']) && $_GET['status'] === '1') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    
    $reportFile = __DIR__ . '/selenium_report.json';
    
    if (file_exists($reportFile)) {
        echo json_encode(['status' => 'done']);
    } else {
        echo json_encode(['status' => 'running']);
    }
    exit;
}

// --- ОБЫЧНЫЙ ЗАХОД ---
$pageTitle  = 'Админ-панель — Selenium Тестирование';
$activeMenu = 'selenium';
$reportExists = file_exists(__DIR__ . '/selenium_report.json');

// Скачивание отчета
if (isset($_GET['download']) && $_GET['download'] === '1' && $reportExists) {
    $file = __DIR__ . '/selenium_report.json';
    $filename = 'selenium_report_' . date('Y-m-d_H-i') . '.json';
    
    header('Content-Description: File Transfer');
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($file));
    
    readfile($file);
    exit;
}

require __DIR__ . '/_header.php';
?>

<div class="card">
    <h2>Тестирование авторизации (Selenium)</h2>
    <p>Инструмент запускает автоматический браузер, который проверяет вход всех тестовых пользователей.</p>
    
    <button type="button" id="runTestBtn" class="btn btn-primary">
        <i class="fas fa-play"></i> Запустить тестирование
    </button>

    <div id="testLoader" style="display: none; margin-top: 20px; text-align: center;">
        <i class="fas fa-spinner fa-spin" style="font-size: 24px; color: #6366f1;"></i>
        <p>Идет тестирование... Пожалуйста, подождите (браузер работает в фоне).</p>
    </div>
    
    <div id="testResult" style="display: none;">
        <h3>Результат:</h3>
        <pre id="testLog" class="selenium-log"></pre>
        
        <div id="downloadBlock" style="display: none; margin-top: 15px;">
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> Отчет успешно сформирован!
            </div>
            <a href="?download=1" class="btn btn-success">
                <i class="fas fa-download"></i> Скачать отчет (JSON)
            </a>
        </div>
    </div>
    
    <?php if ($reportExists) : ?>
        <div class="selenium-actions" style="margin-top: 20px; border-top: 1px solid #eee; padding-top: 20px;">
            <p>Найден отчет от предыдущего запуска:</p>
            <a href="?download=1" class="btn btn-secondary">
                <i class="fas fa-download"></i> Скачать предыдущий отчет
            </a>
        </div>
    <?php endif; ?>
</div>

<script>
document.getElementById('runTestBtn').addEventListener('click', function() {
    const btn = this;
    const loader = document.getElementById('testLoader');
    const resultBlock = document.getElementById('testResult');
    const logBox = document.getElementById('testLog');
    const downloadBlock = document.getElementById('downloadBlock');

    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Выполняется...';
    loader.style.display = 'block';
    resultBlock.style.display = 'none';
    downloadBlock.style.display = 'none';

    // 1. Запускаем тест
    fetch('selenium.php?ajax=1')
        .then(response => response.json())
        .then(data => {
            if (!data.success) {
                throw new Error(data.log);
            }
            
            // 2. Опрашиваем сервер каждые 1.5 секунды
            const checkInterval = setInterval(() => {
                fetch('selenium.php?status=1')
                    .then(res => res.json())
                    .then(statusData => {
                        if (statusData.status === 'done') {
                            clearInterval(checkInterval);
                            
                            loader.style.display = 'none';
                            resultBlock.style.display = 'block';
                            logBox.textContent = "Тестирование успешно завершено!";
                            downloadBlock.style.display = 'block';
                            
                            btn.disabled = false;
                            btn.innerHTML = '<i class="fas fa-play"></i> Запустить тестирование';
                        }
                    })
                    .catch(err => {
                        clearInterval(checkInterval);
                        loader.style.display = 'none';
                        resultBlock.style.display = 'block';
                        logBox.textContent = "Ошибка проверки статуса: " + err.message;
                        btn.disabled = false;
                        btn.innerHTML = '<i class="fas fa-play"></i> Запустить тестирование';
                    });
            }, 1500);
        })
        .catch(error => {
            loader.style.display = 'none';
            resultBlock.style.display = 'block';
            logBox.textContent = 'Ошибка при запуске: ' + error.message;
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-play"></i> Запустить тестирование';
        });
});
</script>

<?php require __DIR__ . '/_footer.php'; ?>