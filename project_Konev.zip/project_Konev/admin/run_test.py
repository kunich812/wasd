import sys
import io
import os
import json
import time
from datetime import datetime
import mysql.connector
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException

# Настройка кодировки для корректного вывода
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

DB_HOST = "localhost"
DB_USER = "admin"
DB_PASS = "admin"
DB_NAME = "project_Konev"
BASE_URL = "http://localhost:8000"  # Убедитесь, что порт правильный!

def get_test_users():
    try:
        conn = mysql.connector.connect(
            host=DB_HOST, user=DB_USER, password=DB_PASS, database=DB_NAME
        )
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT login, password, role FROM `test_users`")
        users = cursor.fetchall()
        cursor.close()
        conn.close()
        return users
    except mysql.connector.Error as err:
        print(f"Ошибка БД: {err}")
        return []

def run_tests():
    users = get_test_users()
    if not users:
        print("Нет тестовых данных в таблице test_users.")
        return

    results = []
    
    options = webdriver.ChromeOptions()
    options.add_argument("--headless=new") # Скрытый режим
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    
    print("Запуск браузера Chrome...")
    try:
        driver = webdriver.Chrome(options=options)
    except Exception as e:
        print(f"Ошибка запуска Chrome: {e}")
        return

    driver.implicitly_wait(3)

    try:
        for u in users:
            login = u['login']
            password = u['password']
            db_role = u['role']
            
            print(f"Тестирование: {login}...", end=" ")
            
            # Открываем страницу в тестовом режиме
            driver.get(f"{BASE_URL}/index.php?test_mode=1")
            
            authorized = False
            session_role = None
            
            try:
                driver.find_element(By.ID, "login").send_keys(login)
                driver.find_element(By.ID, "password").send_keys(password)
                driver.find_element(By.CSS_SELECTOR, "button.btn-login").click()
                
                WebDriverWait(driver, 5).until(EC.url_contains("dashboard.php"))
                authorized = True
                
                role_element = driver.find_element(By.CSS_SELECTOR, ".role-badge")
                session_role = role_element.text.strip()
                
            except TimeoutException:
                authorized = False
            except Exception as e:
                print(f"\nОшибка: {e}")
                authorized = False
                
            role_match = (authorized and session_role == db_role)

            results.append({
                "login": login,
                "password": password,
                "db_role": db_role,
                "authorized": authorized,
                "session_role": session_role,
                "role_match": role_match,
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            })
            
            status = "УСПЕХ" if authorized else "ПРОВАЛ"
            match = "СОВПАЛО" if role_match else "НЕ СОВПАЛО"
            print(f"{status} (Роль: {match})")

            if authorized:
                driver.get(f"{BASE_URL}/logout.php")
                time.sleep(0.3)

    finally:
        driver.quit()

    # Сохраняем JSON
    report_file = "selenium_report.json"
    with open(report_file, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=4)
    
    print(f"\nТестирование завершено. Отчет сохранен в {report_file}")

    # Удаляем lock-файл, чтобы PHP понял, что процесс завершен
    lock_file = os.path.join(os.path.dirname(__file__), 'selenium_running.lock')
    if os.path.exists(lock_file):
        os.remove(lock_file)

if __name__ == "__main__":
    run_tests()