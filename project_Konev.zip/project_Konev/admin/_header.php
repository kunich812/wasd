<?php
/** @var string $pageTitle */
/** @var string $activeMenu */
$pageTitle  = $pageTitle  ?? 'Админ-панель';
$activeMenu = $activeMenu ?? 'users';
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title><?= h($pageTitle) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body { font-family: sans-serif; background: #f4f6f9; padding: 20px; margin: 0; }
        .wrap { max-width: 1200px; margin: 0 auto; }
        .topbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
        .topbar h1 { margin: 0; font-size: 22px; }

        .btn { display: inline-block; padding: 8px 14px; border-radius: 6px; text-decoration: none; font-size: 13px; font-weight: 500; border: none; cursor: pointer; }
        .btn-primary { background: #6366f1; color: white; }
        .btn-secondary { background: #e5e7eb; color: #333; }
        .btn-danger { background: #ef4444; color: white; }
        .btn-warning { background: #f59e0b; color: white; }
        .btn-success { background: #10b981; color: white; }
        .btn-sm { padding: 5px 9px; font-size: 12px; }

        .menu { display: flex; gap: 8px; margin-bottom: 16px; flex-wrap: wrap; }

        .alert { padding: 12px 16px; border-radius: 6px; margin-bottom: 16px; font-size: 14px; }
        .alert-error   { background: rgba(239,68,68,0.1);  border: 1px solid rgba(239,68,68,0.3);  color: #b91c1c; }
        .alert-success { background: rgba(34,197,94,0.1);  border: 1px solid rgba(34,197,94,0.3);  color: #065f46; }
        .alert-info    { background: rgba(59,130,246,0.1); border: 1px solid rgba(59,130,246,0.3); color: #1d4ed8; }

        .card { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 6px rgba(0,0,0,0.04); margin-bottom: 16px; }
        .card h2 { margin-top: 0; font-size: 18px; }

        .form-group { margin-bottom: 14px; }
        .form-group label { display: block; margin-bottom: 6px; font-size: 13px; font-weight: 500; color: #555; }
        .form-group input, .form-group select, .form-group textarea {
            width: 100%; padding: 9px 12px; border: 1.5px solid #ddd; border-radius: 6px;
            font-size: 14px; box-sizing: border-box; font-family: inherit;
        }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus {
            outline: none; border-color: #6366f1;
        }
        .hint { font-size: 11px; color: #888; margin-top: 4px; }

        table { width: 100%; background: white; border-collapse: collapse; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 6px rgba(0,0,0,0.04); }
        th, td { padding: 10px 12px; text-align: left; font-size: 13px; border-bottom: 1px solid #eee; }
        th { background: #f9fafb; color: #555; font-weight: 600; }
        tr:last-child td { border-bottom: none; }

        .tag { display: inline-block; padding: 3px 8px; border-radius: 4px; font-size: 11px; font-weight: 600; }
        .tag-sysadmin { background: #fee2e2; color: #b91c1c; }
        .tag-admin    { background: #fef3c7; color: #b45309; }
        .tag-user     { background: #dbeafe; color: #1d4ed8; }
        .tag-active   { background: #d1fae5; color: #065f46; }
        .tag-blocked  { background: #e5e7eb; color: #374151; }

        .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 12px; margin-bottom: 16px; }
        .stat { background: white; padding: 14px 16px; border-radius: 8px; box-shadow: 0 2px 6px rgba(0,0,0,0.04); }
        .stat .num { font-size: 22px; font-weight: 700; color: #333; }
        .stat .lbl { font-size: 12px; color: #888; margin-top: 4px; }

        .filters { background: white; padding: 14px; border-radius: 8px; margin-bottom: 14px; display: flex; gap: 10px; flex-wrap: wrap; align-items: center; }
        .filters input, .filters select { padding: 7px 10px; border: 1.5px solid #ddd; border-radius: 6px; font-size: 13px; }

        .pagination { display: flex; gap: 6px; justify-content: center; margin: 16px 0; }
        .pagination a, .pagination span {
            padding: 6px 11px; border-radius: 5px; font-size: 13px;
            text-decoration: none; background: white; color: #333; border: 1px solid #e5e7eb;
        }
        .pagination .current { background: #6366f1; color: white; border-color: #6366f1; }
        .pagination .disabled { opacity: .5; }

        .bulk-bar { display: flex; gap: 10px; align-items: center; background: #eef2ff; padding: 10px 14px; border-radius: 6px; margin-bottom: 10px; }
        .bulk-bar select { padding: 6px 10px; border: 1.5px solid #ddd; border-radius: 5px; font-size: 13px; }
    </style>
</head>
<body>
<div class="wrap">
    <div class="topbar">
        <h1><i class="fas fa-shield-alt"></i> <?= h($pageTitle) ?></h1>
        <div>
            <a href="../dashboard.php" class="btn btn-secondary">← В панель</a>
            <a href="../logout.php" class="btn btn-danger">Выйти</a>
        </div>
    </div>

    <div class="menu">
        <a href="index.php"   class="btn btn-<?= $activeMenu === 'users'  ? 'primary' : 'secondary' ?>">Пользователи</a>
        <a href="audit.php"   class="btn btn-<?= $activeMenu === 'audit'  ? 'primary' : 'secondary' ?>">Аудит</a>
        <a href="tables.php"  class="btn btn-<?= $activeMenu === 'tables' ? 'primary' : 'secondary' ?>">Таблицы БД</a>
    </div>