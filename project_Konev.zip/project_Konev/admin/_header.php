<?php

declare(strict_types=1);

/** @var string $pageTitle */
/** @var string $activeMenu */
$pageTitle  = $pageTitle ?? 'Админ-панель';
$activeMenu = $activeMenu ?? 'users';
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title><?= h($pageTitle) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../style.css">
</head>
<body>
<div class="container" style="max-width: 1200px;">
    <div class="topbar">
        <h1><i class="fas fa-shield-alt"></i> <?= h($pageTitle) ?></h1>
        <div>
            <a href="../dashboard.php" class="btn btn-secondary">← В панель</a>
            <a href="../logout.php" class="btn btn-danger" onclick="return confirm('Вы уверены, что хотите выйти из системы?')">Выйти</a>
        </div>
    </div>

        <div class="menu">
        <a href="index.php"    class="btn btn-<?= $activeMenu === 'users'      ? 'primary' : 'secondary' ?>">Пользователи</a>
        <a href="audit.php"    class="btn btn-<?= $activeMenu === 'audit'      ? 'primary' : 'secondary' ?>">Аудит</a>
        <a href="tables.php"   class="btn btn-<?= $activeMenu === 'tables'     ? 'primary' : 'secondary' ?>">Таблицы БД</a>
        <a href="selenium.php" class="btn btn-<?= $activeMenu === 'selenium'   ? 'primary' : 'secondary' ?>">Selenium Тест</a>
        <a href="monitoring.php" class="btn btn-<?= $activeMenu === 'monitoring' ? 'primary' : 'secondary' ?>">Мониторинг</a>
    </div>