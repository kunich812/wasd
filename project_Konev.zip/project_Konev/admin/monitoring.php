<?php

declare(strict_types=1);

require_once __DIR__ . '/_auth.php';

$pageTitle  = 'Админ-панель — Мониторинг';
$activeMenu = 'monitoring';

require __DIR__ . '/_header.php';
?>

<h2 style="display: flex; justify-content: space-between; align-items: center;">
    <span><i class="fas fa-server"></i> Мониторинг сервера</span>
    <!-- Кнопка скачивания JSON -->
    <a href="api/monitoring_data.php?download=1" class="btn btn-success" style="font-size: 14px;">
        <i class="fas fa-download"></i> Экспорт отчета (JSON)
    </a>
</h2>
<p style="color:#888; margin-bottom: 20px;">Данные обновляются автоматически каждые 3 секунды.</p>

<div class="stats">
    <div class="stat" title="Точная дата и время, когда сервер был включен">
        <div class="num" id="sys-start" style="font-size: 18px; color: #6366f1;">—</div>
        <div class="lbl">Время запуска сервера</div>
    </div>
    <div class="stat" title="Сколько времени сервер работает без перезагрузки">
        <div class="num" id="sys-uptime" style="font-size: 18px;">—</div>
        <div class="lbl">Время работы (Uptime)</div>
    </div>
    <div class="stat" title="Время ответа API (за сколько миллисекунд сервер отдает данные)">
        <div class="num" id="site-speed" style="font-size: 18px; color: #10b981;">— ms</div>
        <div class="lbl">Скорость ответа сайта</div>
    </div>
    <div class="stat" title="Время выполнения SQL-запросов к базе данных">
        <div class="num" id="db-speed" style="font-size: 18px; color: #10b981;">— ms</div>
        <div class="lbl">Скорость работы БД</div>
    </div>
    <div class="stat" title="Загрузка жесткого диска">
        <div class="num" id="disk-percent">—%</div>
        <div class="lbl" id="disk-info">Загрузка диска</div>
    </div>
    <div class="stat" title="Загрузка оперативной памяти">
        <div class="num" id="ram-percent">—%</div>
        <div class="lbl" id="ram-info">Загрузка ОЗУ</div>
    </div>
    <div class="stat" title="Загрузка процессора в процентах">
        <div class="num" id="cpu-percent">—%</div>
        <div class="lbl" id="cpu-info">Загрузка CPU</div>
    </div>
    <div class="stat" title="Текущая скорость входящего трафика">
        <div class="num" style="font-size: 18px;" id="net-rx">— КБ/с</div>
        <div class="lbl">Входящий трафик</div>
    </div>
    <div class="stat" title="Текущая скорость исходящего трафика">
        <div class="num" style="font-size: 18px;" id="net-tx">— КБ/с</div>
        <div class="lbl">Исходящий трафик</div>
    </div>
</div>

<h2><i class="fas fa-database"></i> База данных</h2>
<div class="stats">
    <div class="stat" title="Общий объем базы данных">
        <div class="num" id="db-size">— МБ</div>
        <div class="lbl">Размер БД</div>
    </div>
    <div class="stat" title="Количество таблиц в базе">
        <div class="num" id="db-tables">—</div>
        <div class="lbl">Таблиц</div>
    </div>
    <div class="stat" title="Общее количество строк во всех таблицах">
        <div class="num" id="db-rows">—</div>
        <div class="lbl">Записей (строк)</div>
    </div>
</div>

<h2><i class="fas fa-users"></i> Вместимость системы</h2>
<div class="card">
    <div class="stats" style="margin-bottom: 20px;">
        <div class="stat" title="Сколько пользователей зарегистрировано сейчас">
            <div class="num" id="cap-current">—</div>
            <div class="lbl">Текущих пользователей</div>
        </div>
        <div class="stat" title="Максимальное количество пользователей, которое выдержит сервер">
            <div class="num" id="cap-max" style="color: #6366f1;">—</div>
            <div class="lbl">Фактический лимит</div>
        </div>
        <div class="stat" title="Что именно ограничивает систему (ОЗУ, Диск или CPU)">
            <div class="num" id="cap-limit-factor" style="color: #ef4444;">—</div>
            <div class="lbl">Узкое место</div>
        </div>
    </div>

    <p>Заполненность системы (<span id="cap-percent-text">—%</span>):</p>
    <div class="progress-bar">
        <div class="progress-fill" id="cap-bar" style="width: 0%; background: #8b5cf6;"></div>
    </div>
    <p class="hint" style="margin-top: 10px;">
        * Лимит рассчитан динамически на основе свободной ОЗУ, диска и текущей нагрузки на CPU.
    </p>
    
    <details style="margin-top: 15px; font-size: 13px; color: #666;">
        <summary style="cursor: pointer;">Показать детали расчета</summary>
        <ul style="margin-top: 10px; margin-left: 20px;">
            <li>Максимум по ОЗУ: <strong id="cap-ram">—</strong></li>
            <li>Максимум по Диску: <strong id="cap-disk">—</strong></li>
            <li>Максимум по CPU: <strong id="cap-cpu">—</strong></li>
            <li>Размер БД на 1 юзера: <strong id="cap-per-user">—</strong></li>
        </ul>
    </details>
</div>

<div class="card">
    <h3>Загрузка сервера</h3>
    <p>Диск (<span id="disk-bar-text">—%</span>):</p>
    <div class="progress-bar"><div class="progress-fill" id="disk-bar" style="width: 0%;"></div></div>

    <p>Оперативная память (<span id="ram-bar-text">—%</span>):</p>
    <div class="progress-bar"><div class="progress-fill" id="ram-bar" style="width: 0%; background: #10b981;"></div></div>
    
    <p>Процессор (<span id="cpu-bar-text">—%</span>):</p>
    <div class="progress-bar"><div class="progress-fill" id="cpu-bar" style="width: 0%; background: #f59e0b;"></div></div>
</div>

<script src="js/monitoring.js"></script>

<?php require __DIR__ . '/_footer.php'; ?>