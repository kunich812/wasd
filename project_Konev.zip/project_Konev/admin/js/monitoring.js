function setBarColor(id, percent) {
    const bar = document.getElementById(id);
    if (percent > 90) bar.style.background = '#ef4444';
    else if (percent > 75) bar.style.background = '#f59e0b';
    else bar.style.background = (id === 'ram-bar') ? '#10b981' : (id === 'cpu-bar' ? '#f59e0b' : '#6366f1');
}

function updateMonitoring() {
    const startPing = Date.now();

    fetch('api/monitoring_data.php')
        .then(response => {
            if (!response.ok) throw new Error('Network error');
            return response.json();
        })
        .then(data => {
            const endPing = Date.now();
            const pingMs = endPing - startPing;

            // Время сервера
            document.getElementById('sys-start').textContent = data.system.start_time;
            document.getElementById('sys-uptime').textContent = data.system.uptime_text;

            // Скорость сайта
            const speedEl = document.getElementById('site-speed');
            speedEl.textContent = pingMs + ' ms';
            if (pingMs > 300) speedEl.style.color = '#ef4444';
            else if (pingMs > 150) speedEl.style.color = '#f59e0b';
            else speedEl.style.color = '#10b981';

            // Скорость БД
            const dbSpeedEl = document.getElementById('db-speed');
            dbSpeedEl.textContent = data.performance.db_speed_ms + ' ms';
            if (data.performance.db_speed_ms > 500) dbSpeedEl.style.color = '#ef4444';
            else if (data.performance.db_speed_ms > 200) dbSpeedEl.style.color = '#f59e0b';
            else dbSpeedEl.style.color = '#10b981';

            // Диск
            document.getElementById('disk-percent').textContent = data.disk.percent + '%';
            document.getElementById('disk-info').textContent = `Загрузка диска (${data.disk.used_gb} / ${data.disk.total_gb} ГБ)`;
            document.getElementById('disk-bar').style.width = data.disk.percent + '%';
            document.getElementById('disk-bar-text').textContent = data.disk.percent + '%';
            setBarColor('disk-bar', data.disk.percent);

            // ОЗУ
            document.getElementById('ram-percent').textContent = data.ram.percent + '%';
            document.getElementById('ram-info').textContent = `Загрузка ОЗУ (${data.ram.used_gb} / ${data.ram.total_gb} ГБ)`;
            document.getElementById('ram-bar').style.width = data.ram.percent + '%';
            document.getElementById('ram-bar-text').textContent = data.ram.percent + '%';
            setBarColor('ram-bar', data.ram.percent);

            // CPU
            document.getElementById('cpu-percent').textContent = data.cpu.percent + '%';
            document.getElementById('cpu-info').textContent = `Загрузка CPU (${data.cpu.cores} ядер)`;
            document.getElementById('cpu-bar').style.width = data.cpu.percent + '%';
            document.getElementById('cpu-bar-text').textContent = data.cpu.percent + '%';
            setBarColor('cpu-bar', data.cpu.percent);

            // Сеть
            document.getElementById('net-rx').textContent = data.net.rx_kbps + ' КБ/с';
            document.getElementById('net-tx').textContent = data.net.tx_kbps + ' КБ/с';

            // БД
            document.getElementById('db-size').textContent = data.db.size_mb + ' МБ';
            document.getElementById('db-tables').textContent = data.db.tables;
            document.getElementById('db-rows').textContent = data.db.rows;

            // Вместимость
            document.getElementById('cap-current').textContent = data.capacity.users_count;
            document.getElementById('cap-max').textContent = data.capacity.max_total;
            document.getElementById('cap-limit-factor').textContent = data.capacity.limiting_factor;
            
            document.getElementById('cap-ram').textContent = data.capacity.max_by_ram;
            document.getElementById('cap-disk').textContent = data.capacity.max_by_disk;
            document.getElementById('cap-cpu').textContent = data.capacity.max_by_cpu;
            document.getElementById('cap-per-user').textContent = data.capacity.size_per_user_kb + ' КБ';
            
            let capPercent = 0;
            if (data.capacity.max_total > 0) {
                capPercent = Math.min(100, Math.round((data.capacity.users_count / data.capacity.max_total) * 100));
            }
            
            document.getElementById('cap-bar').style.width = capPercent + '%';
            document.getElementById('cap-percent-text').textContent = capPercent + '%';
            
            if (capPercent > 80) {
                document.getElementById('cap-bar').style.background = '#ef4444';
            } else {
                document.getElementById('cap-bar').style.background = '#8b5cf6';
            }
        })
        .catch(err => console.error('Ошибка мониторинга:', err));
}

updateMonitoring();
setInterval(updateMonitoring, 3000);