<?php

declare(strict_types=1);

require_once __DIR__ . '/_auth.php';

$pageTitle  = 'Админ-панель — Редактирование';
$activeMenu = 'users';

$id = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);
if ($id <= 0) {
    header('Location: index.php?msg=err_generic');
    exit;
}

$stmt = $conn->prepare("
    SELECT id_u, last_name, first_name, middle_name, email, login, phone,
           role, is_blocked, password_created_at
    FROM `user` WHERE id_u = ?
");
$stmt->bind_param('i', $id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$user) {
    header('Location: index.php?msg=err_generic');
    exit;
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new = [
        'last_name'   => trim($_POST['last_name'] ?? ''),
        'first_name'  => trim($_POST['first_name'] ?? ''),
        'middle_name' => trim($_POST['middle_name'] ?? ''),
        'email'       => trim($_POST['email'] ?? ''),
        'login'       => trim($_POST['login'] ?? ''),
        'phone'       => trim($_POST['phone'] ?? ''),
        'role'        => $_POST['role'] ?? 'user',
        'is_blocked'  => $_POST['is_blocked'] ?? 'нет',
    ];

    $password  = $_POST['password'] ?? '';
    $password2 = $_POST['password2'] ?? '';

    if ($new['last_name'] === '') {
        $errors[] = 'Укажите фамилию.';
    }
    if ($new['first_name'] === '') {
        $errors[] = 'Укажите имя.';
    }
    if (!filter_var($new['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Некорректный email.';
    }
    if (!preg_match('/^[A-Za-z0-9_]{6,12}$/', $new['login'])) {
        $errors[] = 'Логин: 6–12 символов, только латиница, цифры и подчёркивание.';
    }
    if (!preg_match('/^\+\d{11}$/', $new['phone'])) {
        $errors[] = 'Телефон должен быть в формате +7XXXXXXXXXX.';
    }
    if (!in_array($new['role'], ['sysadmin', 'admin', 'user'], true)) {
        $errors[] = 'Недопустимая роль.';
    }
    if (!in_array($new['is_blocked'], ['нет', 'да'], true)) {
        $errors[] = 'Недопустимый статус блокировки.';
    }

    $changePassword = ($password !== '' || $password2 !== '');
    if ($changePassword) {
        if (mb_strlen($password) < 6 || mb_strlen($password) > 12) {
            $errors[] = 'Новый пароль: 6–12 символов.';
        }
        if ($password !== $password2) {
            $errors[] = 'Пароль и подтверждение не совпадают.';
        }
    }

    if (isSelf($id)) {
        if ($new['role'] !== 'sysadmin') {
            $errors[] = 'Нельзя понизить собственную роль.';
        }
        if ($new['is_blocked'] === 'да') {
            $errors[] = 'Нельзя заблокировать себя.';
        }
    }

    if (!$errors) {
        if ($user['role'] === 'sysadmin' && $user['is_blocked'] === 'нет') {
            $willStopBeingAdmin = ($new['role'] !== 'sysadmin' || $new['is_blocked'] === 'да');
            if ($willStopBeingAdmin) {
                $cnt = (int) $conn->query("
                    SELECT COUNT(*) AS c FROM `user`
                    WHERE role = 'sysadmin' AND is_blocked = 'нет'
                ")->fetch_assoc()['c'];

                if ($cnt <= 1) {
                    $errors[] = 'Это последний активный системный администратор. Нельзя понизить роль или заблокировать.';
                }
            }
        }
    }

    if (!$errors) {
        $stmt = $conn->prepare("
            SELECT id_u, email, login FROM `user`
            WHERE (email = ? OR login = ?) AND id_u <> ?
        ");
        $stmt->bind_param('ssi', $new['email'], $new['login'], $id);
        $stmt->execute();
        $dups = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();

        foreach ($dups as $d) {
            if ($d['email'] === $new['email']) {
                $errors[] = 'Email уже используется другим пользователем.';
            }
            if ($d['login'] === $new['login']) {
                $errors[] = 'Логин уже используется другим пользователем.';
            }
        }
    }

    if (!$errors) {
        if ($changePassword) {
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $conn->prepare("
                UPDATE `user`
                SET last_name = ?, first_name = ?, middle_name = ?,
                    email = ?, login = ?, phone = ?, role = ?,
                    is_blocked = ?, password = ?
                WHERE id_u = ?
            ");
            $stmt->bind_param(
                'sssssssssi',
                $new['last_name'],
                $new['first_name'],
                $new['middle_name'],
                $new['email'],
                $new['login'],
                $new['phone'],
                $new['role'],
                $new['is_blocked'],
                $hash,
                $id
            );
        } else {
            $stmt = $conn->prepare("
                UPDATE `user`
                SET last_name = ?, first_name = ?, middle_name = ?,
                    email = ?, login = ?, phone = ?, role = ?,
                    is_blocked = ?
                WHERE id_u = ?
            ");
            $stmt->bind_param(
                'ssssssssi',
                $new['last_name'],
                $new['first_name'],
                $new['middle_name'],
                $new['email'],
                $new['login'],
                $new['phone'],
                $new['role'],
                $new['is_blocked'],
                $id
            );
        }

        try {
            $stmt->execute();
            $stmt->close();
            header('Location: index.php?msg=updated');
            exit;
        } catch (mysqli_sql_exception $e) {
            $errors[] = 'Не удалось сохранить: ' . $e->getMessage();
            $stmt->close();
        }
    }

    $user = array_merge($user, $new);
}

require __DIR__ . '/_header.php';
?>

<?php if ($errors) : ?>
    <div class="alert alert-error">
        <strong>Не удалось сохранить изменения:</strong>
        <ul style="margin: 8px 0 0 18px;">
            <?php foreach ($errors as $e) : ?>
                <li><?= h($e) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<div class="card" style="max-width: 700px;">
    <h2>
        Редактирование: <?= h($user['login']) ?>
        <span style="color:#999; font-weight:normal;">(id <?= (int) $user['id_u'] ?>)</span>
    </h2>

    <?php if (isSelf($id)) : ?>
        <div class="alert alert-info">
            Это ваш собственный аккаунт. Вы не можете понизить свою роль или заблокировать себя.
        </div>
    <?php endif; ?>

    <form method="post" autocomplete="off">
        <input type="hidden" name="id" value="<?= (int) $user['id_u'] ?>">

        <div class="form-group">
            <label for="last_name">Фамилия *</label>
            <input type="text" id="last_name" name="last_name"
                   value="<?= h($user['last_name']) ?>" required>
        </div>

        <div class="form-group">
            <label for="first_name">Имя *</label>
            <input type="text" id="first_name" name="first_name"
                   value="<?= h($user['first_name']) ?>" required>
        </div>

        <div class="form-group">
            <label for="middle_name">Отчество</label>
            <input type="text" id="middle_name" name="middle_name"
                   value="<?= h($user['middle_name'] ?? '') ?>">
        </div>

        <div class="form-group">
            <label for="email">Email *</label>
            <input type="email" id="email" name="email"
                   value="<?= h($user['email']) ?>" required>
        </div>

        <div class="form-group">
            <label for="login">Логин *</label>
            <input type="text" id="login" name="login"
                   minlength="6" maxlength="12"
                   value="<?= h($user['login']) ?>" required>
        </div>

        <div class="form-group">
            <label for="phone">Телефон *</label>
            <input type="text" id="phone" name="phone"
                   value="<?= h($user['phone']) ?>" required>
        </div>

        <hr style="margin: 20px 0; border: none; border-top: 1px solid #eee;">

        <div class="form-group">
            <label for="password">Новый пароль</label>
            <input type="password" id="password" name="password"
                   minlength="6" maxlength="12" autocomplete="new-password">
            <div class="hint">Оставьте пустым, чтобы не менять пароль</div>
        </div>

        <div class="form-group">
            <label for="password2">Подтверждение пароля</label>
            <input type="password" id="password2" name="password2"
                   minlength="6" maxlength="12" autocomplete="new-password">
        </div>

        <hr style="margin: 20px 0; border: none; border-top: 1px solid #eee;">

        <div class="form-group">
            <label for="role">Роль *</label>
            <select id="role" name="role" required>
                <option value="user" <?= $user['role'] === 'user' ? 'selected' : '' ?>>user — обычный пользователь</option>
                <option value="admin" <?= $user['role'] === 'admin' ? 'selected' : '' ?>>admin — администратор</option>
                <option value="sysadmin" <?= $user['role'] === 'sysadmin' ? 'selected' : '' ?>>sysadmin — системный администратор</option>
            </select>
        </div>

        <div class="form-group">
            <label for="is_blocked">Статус *</label>
            <select id="is_blocked" name="is_blocked" required>
                <option value="нет" <?= $user['is_blocked'] === 'нет' ? 'selected' : '' ?>>Активен</option>
                <option value="да" <?= $user['is_blocked'] === 'да' ? 'selected' : '' ?>>Заблокирован</option>
            </select>
        </div>

        <div class="hint" style="margin-bottom: 16px;">
            Дата последней смены пароля: <strong><?= h($user['password_created_at']) ?></strong>
        </div>

        <button type="submit" class="btn btn-primary">
            <i class="fas fa-save"></i> Сохранить
        </button>
        <a href="index.php" class="btn btn-secondary">Отмена</a>
    </form>
</div>

<?php require __DIR__ . '/_footer.php'; ?>