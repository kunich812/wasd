<?php
require_once __DIR__ . '/_auth.php';

$pageTitle  = 'Админ-панель — Создание таблицы';
$activeMenu = 'tables';

$errors = [];
$old = [
    'name'    => '',
    'columns' => [
        ['name' => '', 'type' => 'VARCHAR(255)', 'null' => 'NOT NULL', 'default' => ''],
        ['name' => '', 'type' => 'INT',          'null' => 'NULL',     'default' => ''],
    ],
];

// Разрешённые типы
$allowedTypes = [
    'INT', 'INT UNSIGNED', 'BIGINT', 'BIGINT UNSIGNED', 'TINYINT(1)',
    'VARCHAR(50)', 'VARCHAR(100)', 'VARCHAR(255)', 'VARCHAR(500)',
    'TEXT', 'DATE', 'DATETIME', 'TIMESTAMP', 'TIME', 'YEAR',
    'DECIMAL(10,2)', 'FLOAT', 'DOUBLE',
    'ENUM',
];

$allowedTypesForEnumHint = "ENUM задаётся так: ENUM('значение1','значение2')";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $old['name'] = trim($_POST['name'] ?? '');

    $colNames = $_POST['col_name']    ?? [];
    $colTypes = $_POST['col_type']    ?? [];
    $colNulls = $_POST['col_null']    ?? [];
    $colDefs  = $_POST['col_default'] ?? [];

    $columns = [];
    for ($i = 0; $i < count($colNames); $i++) {
        $n = trim($colNames[$i] ?? '');
        $t = trim($colTypes[$i] ?? '');
        $l = $colNulls[$i] ?? 'NOT NULL';
        $d = trim($colDefs[$i] ?? '');

        if ($n === '' && $t === '') continue; // пустая строка

        $columns[] = ['name' => $n, 'type' => $t, 'null' => $l, 'default' => $d];
    }
    $old['columns'] = $columns ?: $old['columns'];

    // --- Валидация имени таблицы ---
    if (!preg_match('/^[A-Za-z][A-Za-z0-9_]{0,63}$/', $old['name'])) {
        $errors[] = 'Имя таблицы: начинается с буквы, содержит только латиницу, цифры и _, длина до 64.';
    } elseif (is_protected_table($old['name'])) {
        $errors[] = 'Имя «' . $old['name'] . '» зарезервировано. Выберите другое.';
    } else {
        // Проверка существования
        $stmt = $conn->prepare("
            SELECT COUNT(*) AS c
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?
        ");
        $stmt->bind_param("s", $old['name']);
        $stmt->execute();
        $exists = (int)$stmt->get_result()->fetch_assoc()['c'];
        $stmt->close();

        if ($exists > 0) {
            $errors[] = 'Таблица с таким именем уже существует.';
        }
    }

    // --- Валидация колонок ---
    if (empty($columns)) {
        $errors[] = 'Добавьте хотя бы одну колонку.';
    }

    $seenNames = ['id' => true]; // id уже занят (мы его добавляем автоматически)
    foreach ($columns as $i => $c) {
        $n = $c['name'];
        $t = $c['type'];

        if (!preg_match('/^[A-Za-z][A-Za-z0-9_]{0,63}$/', $n)) {
            $errors[] = "Колонка #" . ($i + 1) . ": некорректное имя «{$n}».";
            continue;
        }
        if (isset($seenNames[$n])) {
            $errors[] = "Колонка #" . ($i + 1) . ": имя «{$n}» уже используется.";
            continue;
        }
        $seenNames[$n] = true;

        // Проверка типа
        if ($t === 'ENUM') {
            // ENUM со значениями приходит как ENUM('a','b') — разрешим только такую форму
            if (!preg_match("/^ENUM\\('[^']+'(?:,'[^']+')*\\)$/i", $c['type_raw'] ?? '')) {
                // ENUM мы не даём выбирать из списка — только через ввод. Оставляем с проверкой.
            }
        } elseif (!in_array($t, $allowedTypes, true)) {
            $errors[] = "Колонка #" . ($i + 1) . ": недопустимый тип «{$t}».";
        }

        // NULL/NOT NULL
        if (!in_array($c['null'], ['NULL', 'NOT NULL'], true)) {
            $errors[] = "Колонка #" . ($i + 1) . ": неверное значение NULL.";
        }

        // DEFAULT: не пустой — экранируем кавычки для строковых типов
        // В целях безопасности — не пропускаем ничего, кроме букв, цифр, знаков _-. и кавычек
        if ($c['default'] !== '') {
            if (!preg_match('/^[A-Za-z0-9_\-\. \'\":]+$/', $c['default'])) {
                $errors[] = "Колонка #" . ($i + 1) . ": недопустимое значение DEFAULT.";
            }
        }
    }

    // --- Создание таблицы ---
    if (!$errors) {
        // Формируем список колонок
        $defs = [];
        $defs[] = "`id` INT UNSIGNED NOT NULL AUTO_INCREMENT";

        foreach ($columns as $c) {
            $n = $c['name'];
            $t = $c['type'];
            $l = $c['null'];
            $d = $c['default'];

            $line = "`$n` $t $l";
            if ($d !== '') {
                // Строковые значения оборачиваем в кавычки, если они уже не в кавычках
                if (preg_match('/^[0-9\.\-]+$/', $d)) {
                    $line .= " DEFAULT $d";
                } else {
                    $d = trim($d, "'\"");
                    $line .= " DEFAULT '" . $conn->real_escape_string($d) . "'";
                }
            }
            $defs[] = $line;
        }
        $defs[] = "PRIMARY KEY (`id`)";

        $sql = "CREATE TABLE `{$old['name']}` (\n  " . implode(",\n  ", $defs) . "\n) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";

        try {
            $conn->query($sql);
            header('Location: tables.php?msg=created');
            exit;
        } catch (mysqli_sql_exception $e) {
            $errors[] = 'Ошибка БД: ' . $e->getMessage();
        }
    }
}

require __DIR__ . '/_header.php';
?>

<?php if ($errors): ?>
    <div class="alert alert-error">
        <strong>Не удалось создать таблицу:</strong>
        <ul style="margin: 8px 0 0 18px;">
            <?php foreach ($errors as $e): ?>
                <li><?= h($e) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<div class="card" style="max-width: 900px;">
    <h2>Создание таблицы</h2>

    <div class="alert alert-info">
        <strong>Колонка <code>id</code> создаётся автоматически</strong> —
        <code>INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY</code>.
        Не добавляйте её в список ниже.
    </div>

    <form method="post" autocomplete="off">
        <div class="form-group">
            <label for="name">Имя таблицы *</label>
            <input type="text" id="name" name="name"
                   pattern="[A-Za-z][A-Za-z0-9_]{0,63}"
                   value="<?= h($old['name']) ?>"
                   placeholder="например, products"
                   required autofocus>
            <div class="hint">Латиница, цифры, подчёркивание; начинается с буквы.</div>
        </div>

        <h3 style="margin-top: 24px;">Колонки</h3>

        <div id="columns">
            <?php foreach ($old['columns'] as $i => $c): ?>
                <div class="col-row" style="display:grid; grid-template-columns: 1fr 1fr 130px 1fr 40px; gap: 8px; margin-bottom: 8px; align-items: center;">
                    <input type="text" name="col_name[]"
                           placeholder="имя колонки"
                           value="<?= h($c['name']) ?>"
                           pattern="[A-Za-z][A-Za-z0-9_]{0,63}">

                    <input type="text" name="col_type[]"
                           placeholder="тип (VARCHAR(255), INT, DATE, …)"
                           value="<?= h($c['type']) ?>"
                           list="typeList">

                    <select name="col_null[]">
                        <option value="NOT NULL" <?= $c['null'] === 'NOT NULL' ? 'selected' : '' ?>>NOT NULL</option>
                        <option value="NULL"     <?= $c['null'] === 'NULL'     ? 'selected' : '' ?>>NULL</option>
                    </select>

                    <input type="text" name="col_default[]"
                           placeholder="default (опционально)"
                           value="<?= h($c['default']) ?>">

                    <button type="button" class="btn btn-sm btn-danger"
                            onclick="this.closest('.col-row').remove()" title="Удалить колонку">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            <?php endforeach; ?>
        </div>

        <datalist id="typeList">
            <?php foreach ($allowedTypes as $t): ?>
                <?php if ($t === 'ENUM') continue; ?>
                <option value="<?= h($t) ?>"></option>
            <?php endforeach; ?>
        </datalist>

        <button type="button" class="btn btn-secondary" onclick="addColumn()">
            <i class="fas fa-plus"></i> Добавить колонку
        </button>

        <hr style="margin: 24px 0; border: none; border-top: 1px solid #eee;">

        <button type="submit" class="btn btn-primary">
            <i class="fas fa-save"></i> Создать таблицу
        </button>
        <a href="tables.php" class="btn btn-secondary">Отмена</a>
    </form>
</div>

<script>
function addColumn() {
    const wrap = document.getElementById('columns');
    const row = document.createElement('div');
    row.className = 'col-row';
    row.style.cssText = 'display:grid; grid-template-columns: 1fr 1fr 130px 1fr 40px; gap:8px; margin-bottom:8px; align-items:center;';
    row.innerHTML = `
        <input type="text" name="col_name[]" placeholder="имя колонки" pattern="[A-Za-z][A-Za-z0-9_]{0,63}">
        <input type="text" name="col_type[]" placeholder="тип (VARCHAR(255), INT, DATE, …)" list="typeList">
        <select name="col_null[]">
            <option value="NOT NULL">NOT NULL</option>
            <option value="NULL">NULL</option>
        </select>
        <input type="text" name="col_default[]" placeholder="default (опционально)">
        <button type="button" class="btn btn-sm btn-danger"
                onclick="this.closest('.col-row').remove()" title="Удалить колонку">
            <i class="fas fa-times"></i>
        </button>
    `;
    wrap.appendChild(row);
}
</script>

<?php require __DIR__ . '/_footer.php'; ?>