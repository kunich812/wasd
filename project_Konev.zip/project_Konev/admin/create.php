<?php

declare(strict_types=1);

require_once __DIR__ . '/_auth.php';

$pageTitle  = 'Админ-панель — Создание пользователя';
$activeMenu = 'users';

$errors = [];
$old = [
    'last_name'   => '',
    'first_name'  => '',
    'middle_name' => '',
    'email'       => '',
    'login'       => '',
    'phone'       => '',
    'role'        => 'user',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $old['last_name']   = trim($_POST['last_name'] ?? '');
    $old['first_name']  = trim($_POST['first_name'] ?? '');
    $old['middle_name'] = trim($_POST['middle_name'] ?? '');
    $old['email']       = trim($_POST['email'] ?? '');
    $old['login']       = trim($_POST['login'] ?? '');
    $old['phone']       = trim($_POST['phone'] ?? '');
    $old['role']        = $_POST['role'] ?? 'user';

    $password  = $_POST['password'] ?? '';
    $password2 = $_POST['password2'] ?? '';

    if ($old['last_name'] === '') {
        $errors[] = 'Укажите фамилию.';
    }
    if ($old['first_name'] === '') {
        $errors[] = 'Укажите имя.';
    }
    if (!filter_var($old['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Некорректный email.';
    }
    if (!preg_match('/^[A-Za-z0-9_]{6,12}$/', $old['login'])) {
        $errors[] = 'Логин: 6–12 символов, только латиница, цифры и подчёркивание.';
    }
    if (!preg_match('/^\+\d{11}$/', $old['phone'])) {
        $errors[] = 'Телефон должен быть в формате +7XXXXXXXXXX (11 цифр после +).';
    }
    if (mb_strlen($password) < 6 || mb_strlen($password) > 12) {
        $errors[] = 'Пароль: 6–12 символов.';
    }
    if ($password !== $password2) {
        $errors[] = 'Пароль и подтверждение не совпадают.';
    }
    if (!in_array($old['role'], ['sysadmin', 'admin', 'user'], true)) {
        $errors[] = 'Недопустимая роль.';
    }

    if (!$errors) {
        $stmt = $conn->prepare("SELECT id_u, email, login FROM `user` WHERE email = ? OR login = ?");
        $stmt->bind_param('ss', $old['email'], $old['login']);
        $stmt->execute();
        $dup = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();

        foreach ($dup as $d) {
            if ($d['email'] === $old['email']) {
                $errors[] = 'Пользователь с таким email уже существует.';
            }
            if ($d['login'] === $old['login']) {
                $errors[] = 'Пользователь с таким логином уже существует.';
            }
        }
    }

    if (!$errors) {
        $hash = password_hash($password, PASSWORD_BCRYPT);

        $stmt = $conn->prepare("
            INSERT INTO `user`
                (last_name, first_name, middle_name, email,
                 password, login, phone, role, is_blocked, password_created_at)
            VALUES
                (?, ?, ?, ?, ?, ?, ?, ?, 'нет', CURDATE())
        ");
        $stmt->bind_param(
            'ssssssss',
            $old['last_name'],
            $old['first_name'],
            $old['middle_name'],
            $old['email'],
            $hash,
            $old['login'],
            $old['phone'],
            $old['role']
        );

        if ($stmt->execute()) {
            $stmt->close();
            header('Location: index.php?msg=created');
            exit;
        } else {
            $errors[] = 'Ошибка БД: ' . $conn->error;
            $stmt->close();
        }
    }
}

require __DIR__ . '/_header.php';
?>

<?php if ($errors) : ?>
    <div class="alert alert-error">
        <strong>Не удалось создать пользователя:</strong>
        <ul style="margin: 8px 0 0 18px;">
            <?php foreach ($errors as $e) : ?>
                <li><?= h($e) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<div class="card" style="max-width: 700px;">
    <h2>Новый пользователь</h2>

    <form method="post" autocomplete="off">
        <div class="form-group">
            <label for="last_name">Фамилия *</label>
            <input type="text" id="last_name" name="last_name"
                   value="<?= h($old['last_name']) ?>" required>
        </div>

        <div class="form-group">
            <label for="first_name">Имя *</label>
            <input type="text" id="first_name" name="first_name"
                   value="<?= h($old['first_name']) ?>" required>
        </div>

        <div class="form-group">
            <label for="middle_name">Отчество</label>
            <input type="text" id="middle_name" name="middle_name"
                   value="<?= h($old['middle_name']) ?>">
            <div class="hint">Можно оставить пустым</div>
        </div>

        <div class="form-group">
            <label for="email">Email *</label>
            <input type="email" id="email" name="email"
                   value="<?= h($old['email']) ?>" required>
        </div>

        <div class="form-group">
            <label for="login">Логин *</label>
            <input type="text" id="login" name="login"
                   minlength="6" maxlength="12"
                   value="<?= h($old['login']) ?>" required>
            <div class="hint">6–12 символов: латиница, цифры, подчёркивание</div>
        </div>

        <div class="form-group">
            <label for="phone">Телефон *</label>
            <input type="text" id="phone" name="phone"
                   placeholder="+79991234567"
                   value="<?= h($old['phone']) ?>" required>
            <div class="hint">Формат: +7XXXXXXXXXX</div>
        </div>

        <div class="form-group">
            <label for="password">Пароль *</label>
            <input type="password" id="password" name="password"
                   minlength="6" maxlength="12" required>
            <div class="hint">6–12 символов</div>
        </div>

        <div class="form-group">
            <label for="password2">Подтверждение пароля *</label>
            <input type="password" id="password2" name="password2"
                   minlength="6" maxlength="12" required>
        </div>

        <div class="form-group">
            <label for="role">Роль *</label>
            <select id="role" name="role" required>
                <option value="user" <?= $old['role'] === 'user' ? 'selected' : '' ?>>user — обычный пользователь</option>
                <option value="admin" <?= $old['role'] === 'admin' ? 'selected' : '' ?>>admin — администратор</option>
                <option value="sysadmin" <?= $old['role'] === 'sysadmin' ? 'selected' : '' ?>>sysadmin — системный администратор</option>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">
            <i class="fas fa-save"></i> Создать
        </button>
        <a href="index.php" class="btn btn-secondary">Отмена</a>
    </form>
</div>

<?php require __DIR__ . '/_footer.php'; ?>