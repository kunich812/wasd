<?php
require_once __DIR__ . '/_auth.php';

$pageTitle  = 'Админ-панель — Таблицы БД';
$activeMenu = 'tables';

// Получаем имя текущей БД
$dbName = $conn->query("SELECT DATABASE()")->fetch_row()[0] ?? '';

// Получаем список таблиц текущей БД (через подготовленный запрос)
$stmt = $conn->prepare("
    SELECT
        TABLE_NAME       AS name,
        TABLE_ROWS       AS rows_approx,
        DATA_LENGTH      AS data_len,
        INDEX_LENGTH     AS idx_len,
        CREATE_TIME      AS created,
        UPDATE_TIME      AS updated
    FROM information_schema.TABLES
    WHERE TABLE_SCHEMA = ?
    ORDER BY TABLE_NAME ASC
");
$stmt->bind_param("s", $dbName);
$stmt->execute();
$tables = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Точное количество строк в каждой таблице
foreach ($tables as &$t) {
    $safeName = '`' . str_replace('`', '``', $t['name']) . '`';
    $cnt = $conn->query("SELECT COUNT(*) AS c FROM $safeName")->fetch_assoc()['c'] ?? 0;
    $t['rows_exact'] = (int)$cnt;
}
unset($t);

// Статистика
$totalTables    = count($tables);
$protectedCount = 0;
$removableCount = 0;
foreach ($tables as $t) {
    if (is_protected_table($t['name'])) {
        $protectedCount++;
    } else {
        $removableCount++;
    }
}

// Хелпер форматирования размера
function formatSize(int $bytes): string {
    if ($bytes < 1024) return $bytes . ' Б';
    if ($bytes < 1024 * 1024) return round($bytes / 1024, 1) . ' КБ';
    return round($bytes / 1024 / 1024, 2) . ' МБ';
}

require __DIR__ . '/_header.php';
?>

<div class="stats">
    <div class="stat"><div class="num"><?= $totalTables ?></div><div class="lbl">Всего таблиц</div></div>
    <div class="stat"><div class="num"><?= $protectedCount ?></div><div class="lbl">Защищённых</div></div>
    <div class="stat"><div class="num"><?= $removableCount ?></div><div class="lbl">Можно удалить</div></div>
    <div class="stat"><div class="num"><?= h($dbName) ?></div><div class="lbl">База данных</div></div>
</div>

<?php if (isset($_GET['msg'])): ?>
    <?php $msg = $_GET['msg']; ?>
    <div class="alert alert-<?= str_starts_with($msg, 'err_') ? 'error' : 'success' ?>">
        <?php
        $messages = [
            'created'     => 'Таблица успешно создана.',
            'dropped'     => 'Таблица удалена.',
            'err_name'    => 'Некорректное имя таблицы.',
            'err_exists'  => 'Таблица с таким именем уже существует.',
            'err_protect' => 'Нельзя удалить защищённую таблицу.',
            'err_sql'     => 'Ошибка при выполнении SQL-запроса.',
            'err_generic' => 'Не удалось выполнить операцию.',
        ];
        echo h($messages[$msg] ?? 'Операция выполнена.');
        ?>
    </div>
<?php endif; ?>

<div class="filters" style="justify-content: space-between;">
    <a href="table_create.php" class="btn btn-success">
        <i class="fas fa-plus"></i> Создать таблицу
    </a>
    <a href="tables.php" class="btn btn-secondary">
        <i class="fas fa-sync"></i> Обновить
    </a>
</div>

<table>
    <thead>
        <tr>
            <th>Таблица</th>
            <th>Строк</th>
            <th>Размер</th>
            <th>Создана</th>
            <th>Изменена</th>
            <th>Статус</th>
            <th style="width: 220px;">Действия</th>
        </tr>
    </thead>
    <tbody>
    <?php if (empty($tables)): ?>
        <tr><td colspan="7" style="text-align:center; color:#888; padding:30px;">
            Таблицы не найдены
        </td></tr>
    <?php else: ?>
        <?php foreach ($tables as $t): ?>
            <?php $protected = is_protected_table($t['name']); ?>
            <tr>
                <td><code><?= h($t['name']) ?></code></td>
                <td><?= $t['rows_exact'] ?></td>
                <td><?= formatSize((int)$t['data_len'] + (int)$t['idx_len']) ?></td>
                <td><?= h($t['created'] ?? '—') ?></td>
                <td><?= h($t['updated'] ?? '—') ?></td>
                <td>
                    <?php if ($protected): ?>
                        <span class="tag tag-sysadmin" title="Системная или защищённая таблица">защищена</span>
                    <?php else: ?>
                        <span class="tag tag-active">обычная</span>
                    <?php endif; ?>
                </td>
                <td>
                    <a href="table_view.php?name=<?= urlencode($t['name']) ?>"
                       class="btn btn-sm btn-secondary" title="Просмотр содержимого">
                        <i class="fas fa-eye"></i>
                    </a>

                    <?php if ($protected): ?>
                        <span class="btn btn-sm btn-secondary" style="opacity:.4; cursor:not-allowed;"
                              title="Защищённая таблица — удаление запрещено">
                            <i class="fas fa-trash"></i>
                        </span>
                    <?php else: ?>
                        <form method="post" action="table_drop.php" style="display:inline;"
                              onsubmit="return confirm('Удалить таблицу <?= h($t['name']) ?>? Все данные будут потеряны безвозвратно!')">
                            <input type="hidden" name="name" value="<?= h($t['name']) ?>">
                            <button type="submit" class="btn btn-sm btn-danger" title="Удалить таблицу">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
    <?php endif; ?>
    </tbody>
</table>

<?php require __DIR__ . '/_footer.php'; ?>