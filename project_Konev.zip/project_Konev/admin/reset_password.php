<?php

declare(strict_types=1);

require_once __DIR__ . '/_auth.php';

$pageTitle  = 'Админ-панель — Сброс пароля';
$activeMenu = 'users';

$id = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);
if ($id <= 0) {
    header('Location: index.php?msg=err_generic');
    exit;
}

if (isSelf($id)) {
    header('Location: index.php?msg=err_self');
    exit;
}

$stmt = $conn->prepare("SELECT id_u, login, last_name, first_name FROM `user` WHERE id_u = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$user) {
    header('Location: index.php?msg=err_generic');
    exit;
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password  = $_POST['password'] ?? '';
    $password2 = $_POST['password2'] ?? '';

    if (mb_strlen($password) < 6 || mb_strlen($password) > 12) {
        $errors[] = 'Пароль: 6–12 символов.';
    }
    if ($password !== $password2) {
        $errors[] = 'Пароль и подтверждение не совпадают.';
    }

    if (!$errors) {
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $conn->prepare("UPDATE `user` SET `password` = ? WHERE id_u = ?");
        $stmt->bind_param('si', $hash, $id);

        try {
            $stmt->execute();
            $stmt->close();
            header('Location: index.php?msg=password_set');
            exit;
        } catch (mysqli_sql_exception $e) {
            $errors[] = 'Не удалось сохранить: ' . $e->getMessage();
            $stmt->close();
        }
    }
}

require __DIR__ . '/_header.php';
?>

<?php if ($errors) : ?>
    <div class="alert alert-error">
        <strong>Не удалось сменить пароль:</strong>
        <ul style="margin: 8px 0 0 18px;">
            <?php foreach ($errors as $e) : ?>
                <li><?= h($e) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<div class="card" style="max-width: 600px;">
    <h2>Сброс пароля</h2>

    <p style="color: #666;">
        Пользователь:
        <strong><?= h($user['last_name'] . ' ' . $user['first_name']) ?></strong>
        (логин: <code><?= h($user['login']) ?></code>, id: <?= (int) $user['id_u'] ?>)
    </p>

    <form method="post" autocomplete="off">
        <input type="hidden" name="id" value="<?= (int) $user['id_u'] ?>">

        <div class="form-group">
            <label for="password">Новый пароль *</label>
            <input type="password" id="password" name="password"
                   minlength="6" maxlength="12" required autofocus>
            <div class="hint">6–12 символов</div>
        </div>

        <div class="form-group">
            <label for="password2">Подтверждение пароля *</label>
            <input type="password" id="password2" name="password2"
                   minlength="6" maxlength="12" required>
        </div>

        <button type="submit" class="btn btn-warning">
            <i class="fas fa-key"></i> Сбросить пароль
        </button>
        <a href="index.php" class="btn btn-secondary">Отмена</a>
    </form>

    <div class="hint" style="margin-top: 16px;">
        После сброса сообщите новый пароль пользователю — он сможет войти с ним.
    </div>
</div>

<?php require __DIR__ . '/_footer.php'; ?>