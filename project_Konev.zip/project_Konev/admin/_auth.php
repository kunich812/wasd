<?php

declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../index.php');
    exit;
}

if (($_SESSION['role'] ?? '') !== 'sysadmin') {
    http_response_code(403);
    exit('Доступ запрещён. Только для системного администратора.');
}

function h(mixed $s): string
{
    return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
}

function isSelf(mixed $id): bool
{
    return (int) $id === (int) $_SESSION['user_id'];
}

const PROTECTED_TABLES = [
    'user',
    'user_audit',
    'information_schema',
    'mysql',
    'performance_schema',
    'sys'
];

function isProtectedTable(string $name): bool
{
    return in_array(strtolower($name), array_map('strtolower', PROTECTED_TABLES), true);
}

function isValidIdentifier(string $name): bool
{
    return (bool) preg_match('/^[A-Za-z][A-Za-z0-9_]{0,63}$/', $name);
}