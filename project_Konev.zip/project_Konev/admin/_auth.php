<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../db.php';

// Только авторизованные
if (!isset($_SESSION['user_id'])) {
    header('Location: ../index.php');
    exit;
}

// Только sysadmin
if (($_SESSION['role'] ?? '') !== 'sysadmin') {
    http_response_code(403);
    exit('Доступ запрещён. Только для системного администратора.');
}

// --- Хелперы ---

/**
 * Экранирование значения для вывода в HTML.
 */
function h(mixed $s): string {
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

/**
 * Проверка: это текущий авторизованный пользователь?
 */
function is_self(mixed $id): bool {
    return (int)$id === (int)$_SESSION['user_id'];
}

// Защищённые таблицы — их нельзя удалять через админку
const PROTECTED_TABLES = ['user', 'user_audit', 'information_schema', 'mysql', 'performance_schema', 'sys'];

/**
 * Проверка: имя таблицы защищено от удаления?
 */
function is_protected_table(string $name): bool {
    return in_array(strtolower($name), array_map('strtolower', PROTECTED_TABLES), true);
}

/**
 * Проверка корректности имени таблицы/столбца:
 * начинается с буквы, содержит буквы/цифры/_, длина 1–64.
 */
function is_valid_identifier(string $name): bool {
    return (bool)preg_match('/^[A-Za-z][A-Za-z0-9_]{0,63}$/', $name);
}