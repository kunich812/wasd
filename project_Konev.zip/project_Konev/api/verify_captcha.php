<?php
session_start();
header('Content-Type: application/json');

$input = strtoupper(trim($_POST['code'] ?? ''));
$real  = $_SESSION['captcha_code'] ?? '';

// Проверяем код. Если он верный — записываем "флаг", что проверка пройдена.
if ($input !== '' && $input === $real) {
    $_SESSION['captcha_verified'] = true;
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false]);
}