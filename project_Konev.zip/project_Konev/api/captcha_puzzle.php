<?php

declare(strict_types=1);

session_start();

header('Content-Type: application/json');

$srcDir = __DIR__ . '/../captcha_src/';
$tmpDir = __DIR__ . '/../captcha_tmp/';

// Создаем папку, если её нет
if (!is_dir($tmpDir)) {
    mkdir($tmpDir, 0777, true);
}

// 1. ОЧИЩАЕМ ПАПКУ ОТ ВСЕХ СТАРЫХ ФАЙЛОВ
$oldFiles = glob($tmpDir . '*');
foreach ($oldFiles as $file) {
    if (is_file($file)) {
        unlink($file);
    }
}

// 2. ВЫБИРАЕМ СЛУЧАЙНУЮ КАРТИНКУ
$images = glob($srcDir . '*.{jpg,jpeg,png}', GLOB_BRACE);
if (empty($images)) {
    echo json_encode(['error' => 'Нет картинок в папке captcha_src']);
    exit;
}

shuffle($images);
$sourceImage = $images[0];

$info = getimagesize($sourceImage);
if (!$info) {
    echo json_encode(['error' => 'Ошибка чтения картинки']);
    exit;
}

switch ($info[2]) {
    case IMAGETYPE_JPEG:
        $img = imagecreatefromjpeg($sourceImage);
        break;
    case IMAGETYPE_PNG:
        $img = imagecreatefrompng($sourceImage);
        break;
    default:
        echo json_encode(['error' => 'Формат не поддерживается']);
        exit;
}

$width  = imagesx($img);
$height = imagesy($img);
$size   = (int) min($width, $height);

$srcX   = (int) (($width - $size) / 2);
$srcY   = (int) (($height - $size) / 2);
$half   = (int) ($size / 2);

// Генерируем уникальный ID для этой конкретной капчи
$captchaId = bin2hex(random_bytes(4)); 

$pieces     = [];
$pieceNames = ['p1', 'p2', 'p3', 'p4'];

$i = 0;
for ($row = 0; $row < 2; $row++) {
    for ($col = 0; $col < 2; $col++) {
        $piece = imagecreatetruecolor($half, $half);
        
        imagealphablending($piece, false);
        imagesavealpha($piece, true);
        $transparent = imagecolorallocatealpha($piece, 0, 0, 0, 127);
        imagefill($piece, 0, 0, $transparent);
        
        imagecopyresampled(
            $piece,
            $img,
            0,
            0,
            (int) ($srcX + ($col * $half)),
            (int) ($srcY + ($row * $half)),
            $half,
            $half,
            $half,
            $half
        );
        
        // Возвращаем уникальные имена файлов (например, a1b2c3d4_p1.png)
        $fileName = "{$captchaId}_{$pieceNames[$i]}.png";
        imagepng($piece, $tmpDir . $fileName);
        
        $pieces[] = $fileName;
        $i++;
    }
}

$_SESSION['puzzle_answer'] = 'p1,p2,p3,p4';

shuffle($pieces);

// Защита от случайной правильной сборки
$currentOrderArr = [];
foreach ($pieces as $file) {
    $parts = explode('_', $file);
    $currentOrderArr[] = str_replace('.png', '', $parts[1]);
}
$currentOrder = implode(',', $currentOrderArr);

while ($currentOrder === $_SESSION['puzzle_answer']) {
    shuffle($pieces);
    $currentOrderArr = [];
    foreach ($pieces as $file) {
        $parts = explode('_', $file);
        $currentOrderArr[] = str_replace('.png', '', $parts[1]);
    }
    $currentOrder = implode(',', $currentOrderArr);
}

echo json_encode([
    'captcha_id' => $captchaId,
    'pieces'     => $pieces
]);