<?php
session_start();
header('Content-Type: application/json');

$srcDir = __DIR__ . '/../captcha_src/';
$tmpDir = __DIR__ . '/../captcha_tmp/';

if (!is_dir($tmpDir)) {
    mkdir($tmpDir, 0777, true);
}

$files = glob($tmpDir . '*');
foreach ($files as $file) {
    if (is_file($file) && time() - filemtime($file) > 3600) {
        unlink($file);
    }
}

$images = glob($srcDir . '*.{jpg,jpeg,png}', GLOB_BRACE);
if (empty($images)) {
    echo json_encode(['error' => 'Нет картинок в папке captcha_src']);
    exit;
}

shuffle($images);
$sourceImage = $images[0];

$info = getimagesize($sourceImage);
if (!$info) {
    echo json_encode(['error' => 'Ошибка чтения картинки']);
    exit;
}

switch ($info[2]) {
    case IMAGETYPE_JPEG: $img = imagecreatefromjpeg($sourceImage); break;
    case IMAGETYPE_PNG:  $img = imagecreatefrompng($sourceImage); break;
    default: 
        echo json_encode(['error' => 'Формат не поддерживается']);
        exit;
}

$width = imagesx($img);
$height = imagesy($img);
$size = min($width, $height);
$srcX = ($width - $size) / 2;
$srcY = ($height - $size) / 2;
$half = $size / 2;

$captchaId = bin2hex(random_bytes(8));
$_SESSION['puzzle_id'] = $captchaId;

$pieces = [];
$pieceNames = ['p1', 'p2', 'p3', 'p4'];

$i = 0;
for ($row = 0; $row < 2; $row++) {
    for ($col = 0; $col < 2; $col++) {
        $piece = imagecreatetruecolor($half, $half);
        imagealphablending($piece, false);
        imagesavealpha($piece, true);
        $transparent = imagecolorallocatealpha($piece, 0, 0, 0, 127);
        imagefill($piece, 0, 0, $transparent);
        
        imagecopyresampled(
            $piece, $img, 
            0, 0, 
            $srcX + ($col * $half), $srcY + ($row * $half), 
            $half, $half, 
            $half, $half
        );
        
        $fileName = "{$captchaId}_{$pieceNames[$i]}.png";
        imagepng($piece, $tmpDir . $fileName);
        $pieces[] = $fileName;
        $i++;
    }
}

$_SESSION['puzzle_answer'] = 'p1,p2,p3,p4';

shuffle($pieces);

echo json_encode([
    'captcha_id' => $captchaId,
    'pieces' => $pieces
]);