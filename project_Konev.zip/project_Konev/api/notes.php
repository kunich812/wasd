<?php
/**
 * API: список заметок.
 * GET /api/notes.php
 *
 * Параметры (все опциональны):
 *   user_id  — int, ID пользователя (фильтр)
 *   limit    — int, 1..100 (по умолчанию 50)
 *   offset   — int, ≥ 0 (по умолчанию 0)
 *
 * Ответы:
 *   200 — JSON-массив заметок (возможно пустой [])
 *   400 — неверный параметр
 *   405 — не GET
 *   500 — ошибка сервера/БД
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');

// --- Хелпер для ответа с ошибкой и завершения ---
function fail(int $code, string $message): void {
    http_response_code($code);
    echo json_encode(
        ['error' => $message],
        JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT
    );
    exit;
}

// --- 1. Проверка метода ---
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    header('Allow: GET');
    fail(405, 'Метод не поддерживается. Используйте GET.');
}

// --- 2. Подключение к БД ---
try {
    require_once __DIR__ . '/../db.php';
} catch (Throwable $e) {
    fail(500, 'Ошибка подключения к базе данных');
}

// --- 3. Валидация параметров ---

// user_id — если передан, должен быть целым положительным
$userId = 0;
if (isset($_GET['user_id'])) {
    $raw = $_GET['user_id'];
    if (!is_string($raw) || !preg_match('/^\d+$/', $raw) || (int)$raw <= 0) {
        fail(400, 'Параметр user_id должен быть целым положительным числом');
    }
    $userId = (int)$raw;
}

// limit — 1..100
$limit = 50;
if (isset($_GET['limit'])) {
    $raw = $_GET['limit'];
    if (!is_string($raw) || !preg_match('/^\d+$/', $raw)) {
        fail(400, 'Параметр limit должен быть целым числом');
    }
    $limit = (int)$raw;
    if ($limit < 1 || $limit > 100) {
        fail(400, 'Параметр limit должен быть в диапазоне от 1 до 100');
    }
}

// offset — ≥ 0
$offset = 0;
if (isset($_GET['offset'])) {
    $raw = $_GET['offset'];
    if (!is_string($raw) || !preg_match('/^\d+$/', $raw)) {
        fail(400, 'Параметр offset должен быть целым неотрицательным числом');
    }
    $offset = (int)$raw;
}

// --- 4. Запрос к БД ---
$where  = [];
$params = [];
$types  = '';

if ($userId > 0) {
    $where[]  = "n.id_user = ?";
    $params[] = $userId;
    $types   .= 'i';
}

$whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$sql = "
    SELECT
        n.id,
        n.title,
        n.content,
        n.created_at,
        u.login AS user_login
    FROM `notes` n
    LEFT JOIN `user` u ON u.id_u = n.id_user
    $whereSql
    ORDER BY n.created_at DESC, n.id DESC
    LIMIT ? OFFSET ?
";

$stmt   = null;
$result = null;

try {
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        throw new RuntimeException('Ошибка подготовки SQL-запроса');
    }

    $paramsWithLimit   = $params;
    $paramsWithLimit[] = $limit;
    $paramsWithLimit[] = $offset;
    $typesWithLimit    = $types . 'ii';

    $stmt->bind_param($typesWithLimit, ...$paramsWithLimit);

    if (!$stmt->execute()) {
        throw new RuntimeException('Ошибка выполнения SQL-запроса');
    }

    $result = $stmt->get_result();
    if ($result === false) {
        throw new RuntimeException('Ошибка получения результата');
    }
} catch (Throwable $e) {
    // Логируем детали, а клиенту отдаём общее сообщение
    error_log('API notes error: ' . $e->getMessage());
    fail(500, 'Внутренняя ошибка сервера');
}

// --- 5. Формирование ответа ---
$notes = [];
while ($row = $result->fetch_assoc()) {
    // 1. id: число → строка с ведущими нулями до 5 знаков
    $id = str_pad((string)$row['id'], 5, '0', STR_PAD_LEFT);

    // 2. title_user: заголовок + " - " + логин автора
    $login     = $row['user_login'] ?? 'unknown';
    $titleUser = $row['title'] . ' - ' . $login;

    // 3. content: экранируем HTML-спецсимволы
    $content = $row['content'];

    // 4. formatted_date: DD.MM.YYYY
    try {
        $dt = new DateTime($row['created_at']);
        $formattedDate = $dt->format('d.m.Y');
    } catch (Throwable $e) {
        $formattedDate = '';
    }

    $notes[] = [
        'id'             => $id,
        'title_user'     => $titleUser,
        'content'        => $content,
        'formatted_date' => $formattedDate,
    ];
}

// Закрываем statement только если он был успешно создан
if ($stmt instanceof mysqli_stmt) {
    $stmt->close();
}

// Пустой массив — это корректный ответ (200 OK)
echo json_encode($notes, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);