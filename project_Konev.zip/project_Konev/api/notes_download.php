<?php

declare(strict_types=1);

session_start();
require_once __DIR__ . '/../db.php';

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    exit('Неавторизованный доступ');
}

$isAdmin = in_array($_SESSION['role'] ?? '', ['sysadmin', 'admin'], true);
$userId  = (int) $_SESSION['user_id'];

$where  = [];
$params = [];
$types  = '';

if (!$isAdmin) {
    $where[]  = "n.id_user = ?";
    $params[] = $userId;
    $types   .= 'i';
}

$whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$sql = "
    SELECT
        n.id,
        n.title,
        n.content,
        n.created_at,
        u.login AS user_login
    FROM `notes` n
    LEFT JOIN `user` u ON u.id_u = n.id_user
    $whereSql
    ORDER BY n.created_at DESC, n.id DESC
";

$stmt = $conn->prepare($sql);
if ($params) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();

$notes = [];
while ($row = $result->fetch_assoc()) {
    $id = str_pad((string) $row['id'], 5, '0', STR_PAD_LEFT);
    $login     = $row['user_login'] ?? 'unknown';
    $titleUser = $row['title'] . ' - ' . $login;
    
    try {
        $dt = new DateTime($row['created_at']);
        $formattedDate = $dt->format('d.m.Y');
    } catch (Throwable $e) {
        $formattedDate = '';
    }

    $notes[] = [
        'id'             => $id,
        'title_user'     => $titleUser,
        'content'        => $row['content'],
        'formatted_date' => $formattedDate,
    ];
}
$stmt->close();

$filename = 'notes_' . date('Y-m-d_H-i') . '.json';

header('Content-Type: application/json; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Pragma: no-cache');

echo json_encode($notes, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
exit;