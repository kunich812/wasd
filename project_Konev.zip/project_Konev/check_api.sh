#!/bin/bash
#
# check_api.sh — проверка HTTP-статусов API /api/notes.php
# Запуск: bash check_api.sh
#

BASE="http://localhost:8000/api/notes.php"
DB="db.php"

echo "════════════════════════════════════════════════════"
echo "  Проверка API: $BASE"
echo "════════════════════════════════════════════════════"

# ─── 1. Данные есть → 200 OK ───────────────────────
echo ""
echo "─── 1. Данные есть (ожидание: 200 OK) ───────────"
curl -s -o /dev/null -w "Статус: %{http_code}\n" "$BASE"

# ─── 2. Пусто → 200 OK + [] ────────────────────────
echo ""
echo "─── 2. Пусто, user_id=99999 (ожидание: 200 OK) ──"
curl -s -o /dev/null -w "Статус: %{http_code}\n" "$BASE?user_id=99999"
echo "Тело:"
curl -s "$BASE?user_id=99999"
echo ""

# ─── 3. Некорректный параметр → 400 ────────────────
echo ""
echo "─── 3. user_id=abc (ожидание: 400 Bad Request) ──"
curl -s -o /dev/null -w "Статус: %{http_code}\n" "$BASE?user_id=abc"
echo "Тело:"
curl -s "$BASE?user_id=abc"
echo ""

echo ""
echo "─── 3б. limit=1000 (ожидание: 400) ──────────────"
curl -s -o /dev/null -w "Статус: %{http_code}\n" "$BASE?limit=1000"
echo "Тело:"
curl -s "$BASE?limit=1000"
echo ""

# ─── 4. Метод не GET → 405 ─────────────────────────
echo ""
echo "─── 4. POST (ожидание: 405 Method Not Allowed) ──"
curl -s -o /dev/null -w "Статус: %{http_code}\n" -X POST "$BASE"
echo "Тело:"
curl -s -X POST "$BASE"
echo ""

# ─── 5. Внутренняя ошибка → 500 ────────────────────
echo ""
echo "─── 5. Ошибка БД (ожидание: 500 Server Error) ───"
if [ -f "$DB" ]; then
    mv "$DB" "$DB.bak"
    echo "  → db.php временно переименован"
    curl -s -o /dev/null -w "Статус: %{http_code}\n" "$BASE"
    echo "Тело:"
    curl -s "$BASE"
    echo ""
    mv "$DB.bak" "$DB"
    echo "  → db.php восстановлен"
else
    echo "  ⚠ db.php не найден — пропуск проверки"
fi

# ─── Финальная проверка ────────────────────────────
echo ""
echo "─── Проверка, что сервер снова работает ──────────"
curl -s -o /dev/null -w "Статус: %{http_code}\n" "$BASE"

echo ""
echo "════════════════════════════════════════════════════"
echo "  Готово."
echo "════════════════════════════════════════════════════"
