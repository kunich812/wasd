<?php

declare(strict_types=1);

session_start();

header('Content-Type: image/png');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

$width  = 200;
$height = 70;

$img = imagecreatetruecolor($width, $height);

// Фон — светлый градиент сверху вниз
for ($y = 0; $y < $height; $y++) {
    $r = 230 + (int) (($y / $height) * 20);
    $g = 235 + (int) (($y / $height) * 15);
    $b = 245;
    $color = imagecolorallocate($img, $r, $g, $b);
    imageline($img, 0, $y, $width, $y, $color);
}

// Случайный код из 5 символов
$chars = 'ABCDEFGHJKMNPQRTUVWXY346789';
$code  = '';
for ($i = 0; $i < 5; $i++) {
    $code .= $chars[random_int(0, strlen($chars) - 1)];
}

// Запоминаем в сессии
$_SESSION['captcha_code'] = $code;

// Помехи — линии
for ($i = 0; $i < 8; $i++) {
    $lineColor = imagecolorallocate(
        $img,
        random_int(120, 200),
        random_int(120, 200),
        random_int(120, 200)
    );
    imageline(
        $img,
        random_int(0, $width),
        random_int(0, $height),
        random_int(0, $width),
        random_int(0, $height),
        $lineColor
    );
}

// Помехи — точки
for ($i = 0; $i < 400; $i++) {
    $dotColor = imagecolorallocate(
        $img,
        random_int(100, 210),
        random_int(100, 210),
        random_int(100, 210)
    );
    imagesetpixel($img, random_int(0, $width), random_int(0, $height), $dotColor);
}

// Основные символы
$fontFile = __DIR__ . '/fonts/static/Arimo-Bold.ttf';
$fontSize = 28;

for ($i = 0; $i < 5; $i++) {
    $color = imagecolorallocate(
        $img,
        random_int(10, 80),
        random_int(10, 80),
        random_int(10, 80)
    );

    $angle = random_int(-25, 25);
    $x     = 20 + $i * 32 + random_int(-3, 3);
    $y     = 48 + random_int(-6, 6);

    imagettftext(
        $img,
        $fontSize,
        $angle,
        $x,
        $y,
        $color,
        $fontFile,
        $code[$i]
    );
}

imagepng($img);