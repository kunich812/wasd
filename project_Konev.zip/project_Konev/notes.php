<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}
$isAdmin = in_array($_SESSION['role'] ?? '', ['sysadmin', 'admin'], true);
$userId  = (int)$_SESSION['user_id'];
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Заметки</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <div class="topbar-notes">
        <h1><i class="fas fa-sticky-note"></i> Заметки</h1>
        <div>
            <a href="api/notes_download.php" class="btn btn-success">
                <i class="fas fa-download"></i> Скачать JSON
            </a>
            <button class="btn btn-primary" id="refreshBtn">
                <i class="fas fa-sync"></i> Обновить
            </button>
            <a href="dashboard.php" class="btn btn-secondary">← На главную</a>
            <a href="logout.php" class="btn btn-danger" onclick="return confirm('Вы уверены, что хотите выйти из системы?')">Выйти</a>
        </div>
    </div>

    <?php if ($isAdmin): ?>
        <div class="info"><i class="fas fa-info-circle"></i> Вы видите <strong>все</strong> заметки всех пользователей.</div>
    <?php else: ?>
        <div class="info"><i class="fas fa-info-circle"></i> Вы видите только <strong>свои</strong> заметки.</div>
    <?php endif; ?>

    <div class="stats-bar">
        <span>Пользователь: <strong><?= htmlspecialchars($_SESSION['login']) ?></strong></span>
        <span>Роль: <strong><?= htmlspecialchars($_SESSION['role']) ?></strong></span>
        <span>Показано: <strong id="count">—</strong></span>
    </div>

    <div id="notes" class="notes-grid">
        <div class="loading"><i class="fas fa-spinner fa-spin"></i> Загрузка заметок…</div>
    </div>
</div>

<script>
const isAdmin = <?= $isAdmin ? 'true' : 'false' ?>;
const userId  = <?= $userId ?>;

async function loadNotes() {
    const container = document.getElementById('notes');
    const countEl   = document.getElementById('count');
    container.innerHTML = `<div class="loading"><i class="fas fa-spinner fa-spin"></i> Загрузка заметок…</div>`;

    const url = isAdmin ? 'api/notes.php?limit=100' : `api/notes.php?limit=100&user_id=${userId}`;

    try {
        const res = await fetch(url);
        if (!res.ok) {
            let errMsg = `Ошибка ${res.status}`;
            try { const errData = await res.json(); if (errData.error) errMsg += ': ' + errData.error; } catch (e) {}
            throw new Error(errMsg);
        }
        const notes = await res.json();
        countEl.textContent = notes.length;

        if (notes.length === 0) {
            container.innerHTML = `<div class="empty"><i class="fas fa-inbox"></i> Заметок пока нет</div>`;
            return;
        }

        container.innerHTML = notes.map(note => `
            <div class="note-card">
                <div class="note-header">
                    <div class="note-title">${escapeHtml(note.title_user)}</div>
                    <div class="note-id">#${escapeHtml(note.id)}</div>
                </div>
                <div class="note-content">${escapeHtml(note.content)}</div>
                <div class="note-footer">
                    <span><i class="fas fa-calendar-alt"></i> ${escapeHtml(note.formatted_date)}</span>
                </div>
            </div>
        `).join('');
    } catch (err) {
        container.innerHTML = `<div class="error"><i class="fas fa-exclamation-triangle"></i> ${escapeHtml(err.message)}</div>`;
        countEl.textContent = '—';
    }
}

function escapeHtml(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
document.getElementById('refreshBtn').addEventListener('click', loadNotes);
loadNotes();
</script>
</body>
</html>