<?php

declare(strict_types=1);

$host = 'localhost';
$db   = 'project_Konev';
$user = 'admin';
$pass = 'admin';
$charset = 'utf8mb4';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die('Ошибка подключения: ' . $conn->connect_error);
}

$conn->set_charset($charset);