<?php
$host = 'localhost';
$db   = 'project_Konev'; // Имя вашей БД
$user = 'admin';          // Ваше имя пользователя MySQL
$pass = 'admin';              // Ваш пароль от MySQL
$charset = 'utf8mb4';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}

$conn->set_charset($charset);
?>