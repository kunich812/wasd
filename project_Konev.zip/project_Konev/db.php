<?php
$host = 'localhost';
$db   = 'project_Konev'; // Имя вашей БД
$user = 'admin';          // Ваше имя пользователя MySQL
$pass = 'admin';              // Ваш пароль от MySQL
$charset = 'utf8mb4';

$conn = new mysqli($host, $user, $pass, $db);


$conn->set_charset($charset);
?>