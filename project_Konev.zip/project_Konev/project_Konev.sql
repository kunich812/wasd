-- phpMyAdmin SQL Dump
-- version 5.1.3-3.red80
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Окт 19 2026 г., 04:27
-- Версия сервера: 10.11.11-MariaDB
-- Версия PHP: 8.1.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `project_Konev`
--

DELIMITER $$
--
-- Процедуры
--
CREATE DEFINER=`admin`@`localhost` PROCEDURE `sp_login_user` (IN `p_login` VARCHAR(12), OUT `p_id_u` INT UNSIGNED, OUT `p_password_hash` VARCHAR(255), OUT `p_role` VARCHAR(20), OUT `p_first_name` VARCHAR(50), OUT `p_last_name` VARCHAR(50), OUT `p_email` VARCHAR(255), OUT `p_is_blocked` VARCHAR(3), OUT `p_password_expired` TINYINT, OUT `p_status` VARCHAR(20))   BEGIN
    DECLARE v_count INT DEFAULT 0;

    SELECT COUNT(*) INTO v_count FROM `user` WHERE login = p_login;

    IF v_count = 0 THEN
        SET p_status = 'not_found';
        SET p_id_u = NULL;
    ELSE
        SELECT
            id_u,
            password,
            role,
            first_name,
            last_name,
            email,
            is_blocked,
            (password_created_at <= CURDATE() - INTERVAL 6 MONTH)
        INTO
            p_id_u,
            p_password_hash,
            p_role,
            p_first_name,
            p_last_name,
            p_email,
            p_is_blocked,
            p_password_expired
        FROM `user`
        WHERE login = p_login
        LIMIT 1;

        IF p_is_blocked = 'да' THEN
            SET p_status = 'blocked';
        ELSE
            SET p_status = 'ok';
        END IF;
    END IF;
END$$

CREATE DEFINER=`admin`@`localhost` PROCEDURE `sp_register_user` (IN `p_last_name` VARCHAR(50), IN `p_first_name` VARCHAR(50), IN `p_middle_name` VARCHAR(50), IN `p_email` VARCHAR(255), IN `p_password` VARCHAR(255), IN `p_login` VARCHAR(12), IN `p_phone` VARCHAR(16), IN `p_role` VARCHAR(20), OUT `p_id_u` INT UNSIGNED, OUT `p_status` VARCHAR(50))   BEGIN
    DECLARE v_exists INT DEFAULT 0;

    -- Проверка длины логина
    IF CHAR_LENGTH(p_login) < 6 OR CHAR_LENGTH(p_login) > 12 THEN
        SET p_status = 'error: логин должен быть от 6 до 12 символов';
        SET p_id_u = NULL;
    ELSE
        -- Проверка на дубликат
        SELECT COUNT(*) INTO v_exists
        FROM `user`
        WHERE email = p_email OR login = p_login;

        IF v_exists > 0 THEN
            SET p_status = 'error: пользователь с таким email или логином уже существует';
            SET p_id_u = NULL;
        ELSE
            INSERT INTO `user`
                (last_name, first_name, middle_name, email,
                 password, login, phone, role, is_blocked, password_created_at)
            VALUES
                (p_last_name, p_first_name, p_middle_name, p_email,
                 p_password, p_login, p_phone, p_role, 'нет', CURDATE());

            SET p_id_u = LAST_INSERT_ID();
            SET p_status = 'ok';
        END IF;
    END IF;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Структура таблицы `notes`
--

CREATE TABLE `notes` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `id_user` int(10) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `notes`
--

INSERT INTO `notes` (`id`, `title`, `content`, `id_user`, `created_at`) VALUES
(7, 'Конференция ИТ', 'Содержимое заметки', 8, '2027-04-15 10:00:00'),
(8, 'Встреча с командой', 'Обсудили планы <script>alert(1)</script>', 3, '2027-04-16 14:30:00'),
(9, 'Заметка без автора', 'Тест JOIN', 2, '2027-04-17 09:15:00');

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE `user` (
  `id_u` int(10) UNSIGNED NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `login` varchar(12) NOT NULL,
  `phone` varchar(16) NOT NULL,
  `role` enum('sysadmin','admin','user') NOT NULL DEFAULT 'user',
  `is_blocked` enum('нет','да') NOT NULL DEFAULT 'нет',
  `password_created_at` date NOT NULL DEFAULT curdate()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `user`
--

INSERT INTO `user` (`id_u`, `last_name`, `first_name`, `middle_name`, `email`, `password`, `login`, `phone`, `role`, `is_blocked`, `password_created_at`) VALUES
(2, 'Кузнецов', 'Кирилл', 'Андреевич', 'kuznetsov@mail.ru', '$2y$10$EDmq/HCstgKqC/jCz18F/.c4dgO23FEC08b7Q.Fed.YIG1FDMRcIa', 'sysadmin_2', '+79990000002', 'sysadmin', 'да', '2026-10-07'),
(3, 'Иванов', 'Иван', 'Иванович', 'ivanov@mail.ru', '$2y$10$c10LTpxXFvL4cYOuof6uFueuq6KNpp3roK0BEAda.kAktScaQz2O2', 'admin_01', '+79990000003', 'admin', 'нет', '2026-10-07'),
(4, 'Петров', 'Пётр', 'Сергеевич', 'petrov@mail.ru', '$2y$10$FIMjOUj5JdPnDuTuZteHHeiQQhKvd7..uifaWnELB4eN2m8ZdSRM.', 'admin_02', '+79990000004', 'admin', 'да', '2026-10-07'),
(5, 'Смирнов', 'Алексей', 'Николаевич', 'smirnov@mail.ru', '$2y$10$/iYV8u43.KJaO0VFHh6lKu/XXQ/8ndN4u5nzROQEMEAGZCc3Rk46e', 'user_001', '+79990000005', 'user', 'нет', '2026-10-12'),
(7, 'Фёдоров', 'Фёдор', 'Фёдорович', 'fedorov@mail.ru', '$2y$10$h3ytbPGoM96ElE8qiCpLrOANR/V1y0GJGXPxGx02syIwdLVxCZV5O', 'user_003', '+79990000009', 'user', 'нет', '2026-10-07'),
(8, 'Сидоров', 'Сергей', 'Петрович', 'sidorov@mail.ru', '$2y$10$GUcSJVYQs9aJ.wD9SVA3ROyTiJY74osKUgPvZGSXGowxfLo0AdLrq', 'sysadmin_1', '+79990000001', 'sysadmin', 'нет', '2026-10-08'),
(9, 'Варычев', 'Илья', 'Александрович', 'test@mail.ru', '$2y$10$x.15.Q9O7AKuxBsTieMRtOQdbQFxD1sVuh59z5spho7F10s1Iu6t.', 'test_01', '+79991112233', 'admin', 'нет', '2026-10-12');

--
-- Триггеры `user`
--
DELIMITER $$
CREATE TRIGGER `trg_user_after_update` AFTER UPDATE ON `user` FOR EACH ROW BEGIN
    -- Смена роли
    IF NEW.role <> OLD.role THEN
        INSERT INTO `user_audit` (id_u, action, old_value, new_value, changed_by)
        VALUES (NEW.id_u, 'role_changed', OLD.role, NEW.role, USER());
    END IF;

    -- Смена блокировки
    IF NEW.is_blocked <> OLD.is_blocked THEN
        INSERT INTO `user_audit` (id_u, action, old_value, new_value, changed_by)
        VALUES (
            NEW.id_u,
            IF(NEW.is_blocked = 'да', 'blocked', 'unblocked'),
            OLD.is_blocked,
            NEW.is_blocked,
            USER()
        );
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_user_before_delete` BEFORE DELETE ON `user` FOR EACH ROW BEGIN
    -- Защищаем только активного sysadmin
    IF OLD.role = 'sysadmin' AND OLD.is_blocked = 'нет' THEN

        -- Считаем, сколько ЕЩЁ активных sysadmin останется после удаления
        IF (SELECT COUNT(*) FROM `user`
            WHERE role = 'sysadmin' AND is_blocked = 'нет') <= 1 THEN

            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'Нельзя удалить последнего активного системного администратора';
        END IF;
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_user_before_insert` BEFORE INSERT ON `user` FOR EACH ROW BEGIN
    -- Автоматически проставляем дату, если не указана
    IF NEW.password_created_at IS NULL THEN
        SET NEW.password_created_at = CURDATE();
    END IF;

    -- Логин: 6–12 символов
    IF CHAR_LENGTH(NEW.login) < 6 OR CHAR_LENGTH(NEW.login) > 12 THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Логин должен содержать от 6 до 12 символов';
    END IF;

    -- Email: базовая проверка на наличие @ и точки
    IF NEW.email NOT LIKE '%_@_%._%' THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Некорректный email';
    END IF;

    -- Роль: только допустимые значения
    IF NEW.role NOT IN ('sysadmin', 'admin', 'user') THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Недопустимая роль';
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_user_before_update_block` BEFORE UPDATE ON `user` FOR EACH ROW BEGIN
    -- Блокируем активного sysadmin?
    IF OLD.role = 'sysadmin'
       AND OLD.is_blocked = 'нет'
       AND NEW.is_blocked = 'да' THEN

        -- И после блокировки не останется ни одного активного?
        IF (SELECT COUNT(*) FROM `user`
            WHERE role = 'sysadmin' AND is_blocked = 'нет') <= 1 THEN

            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'Нельзя заблокировать последнего активного системного администратора';
        END IF;
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_user_password_changed` BEFORE UPDATE ON `user` FOR EACH ROW BEGIN
    IF NEW.password <> OLD.password THEN
        SET NEW.password_created_at = CURDATE();
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Структура таблицы `user_audit`
--

CREATE TABLE `user_audit` (
  `audit_id` int(10) UNSIGNED NOT NULL,
  `id_u` int(10) UNSIGNED NOT NULL,
  `action` varchar(20) NOT NULL,
  `old_value` varchar(50) DEFAULT NULL,
  `new_value` varchar(50) DEFAULT NULL,
  `changed_by` varchar(64) DEFAULT NULL,
  `changed_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `user_audit`
--

INSERT INTO `user_audit` (`audit_id`, `id_u`, `action`, `old_value`, `new_value`, `changed_by`, `changed_at`) VALUES
(1, 7, 'role_changed', 'user', 'admin', 'admin@localhost', '2026-10-08 10:26:52'),
(2, 7, 'role_changed', 'admin', 'user', 'admin@localhost', '2026-10-08 10:28:04'),
(3, 9, 'role_changed', 'user', 'admin', 'admin@localhost', '2026-10-12 10:15:25'),
(4, 5, 'blocked', 'нет', 'да', 'admin@localhost', '2026-10-12 10:23:49'),
(5, 7, 'blocked', 'нет', 'да', 'admin@localhost', '2026-10-12 10:23:49'),
(6, 9, 'blocked', 'нет', 'да', 'admin@localhost', '2026-10-12 10:23:49'),
(7, 5, 'unblocked', 'да', 'нет', 'admin@localhost', '2026-10-12 10:23:55'),
(8, 7, 'unblocked', 'да', 'нет', 'admin@localhost', '2026-10-12 10:23:55'),
(9, 9, 'unblocked', 'да', 'нет', 'admin@localhost', '2026-10-12 10:23:55');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `notes`
--
ALTER TABLE `notes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_user` (`id_user`);

--
-- Индексы таблицы `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_u`),
  ADD UNIQUE KEY `uq_user_email` (`email`),
  ADD UNIQUE KEY `uq_user_login` (`login`),
  ADD UNIQUE KEY `uq_user_password` (`password`);

--
-- Индексы таблицы `user_audit`
--
ALTER TABLE `user_audit`
  ADD PRIMARY KEY (`audit_id`),
  ADD KEY `idx_user_audit_id_u` (`id_u`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `notes`
--
ALTER TABLE `notes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `user`
--
ALTER TABLE `user`
  MODIFY `id_u` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `user_audit`
--
ALTER TABLE `user_audit`
  MODIFY `audit_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `notes`
--
ALTER TABLE `notes`
  ADD CONSTRAINT `fk_notes_user` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_u`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
